export type Position = {
  x: number;
  y: number;
};

export type TileType = 
  | 'EMPTY'        // 0
  | 'WALL'         // 1
  | 'GATE_ALPHA'   // 2 - alternates state
  | 'GATE_BETA'    // 3 - alternates inverted
  | 'GATE_GAMMA'   // 4 - 3rd phase gate
  | 'SHARD'        // 5 - optional golden relic
  | 'EXIT';        // 9

export interface LevelData {
  id: number;
  name: string;
  subtitle: string;
  description: string;
  width: number;
  height: number;
  layout: number[][]; // 2D array of tile integers
  playerStart: Position;
  hunterStart: Position;
  exit: Position;
  shiftCycleLength: number;
  parMoves: number;
  lore: string;
}

export type GameStatus = 
  | 'TITLE'
  | 'PLAYING'
  | 'LEVEL_WON'
  | 'GAME_OVER'
  | 'VICTORY';

export interface GameStats {
  moves: number;
  shardsCollected: number;
  totalShards: number;
  hunterDistance: number;
  timeElapsed: number; // in seconds
}
