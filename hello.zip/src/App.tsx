/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Header } from './components/Header';
import { HUD } from './components/HUD';
import { MazeBoard } from './components/MazeBoard';
import { Controls } from './components/Controls';
import { RulesModal, ExportModal, LevelWonModal, GameOverModal } from './components/Modals';
import { LEVELS } from './levels';
import { Position, GameStatus } from './types';
import { sound } from './audio';
import { 
  TILE_EMPTY, 
  TILE_SHARD, 
  isTileWalkable, 
  getNextHunterMove, 
  isMazeSolvable,
  findShortestPath
} from './pathfinding';

export default function App() {
  const [levelIdx, setLevelIdx] = useState(0);
  const currentLevel = LEVELS[levelIdx];

  // Grid and positions
  const [grid, setGrid] = useState<number[][]>(() => currentLevel.layout.map(r => [...r]));
  const [playerPos, setPlayerPos] = useState<Position>(currentLevel.playerStart);
  const [prevPlayerPos, setPrevPlayerPos] = useState<Position | null>(null);
  
  const [hunterPos, setHunterPos] = useState<Position>(currentLevel.hunterStart);
  const [prevHunterPos, setPrevHunterPos] = useState<Position | null>(null);

  const [shiftPhase, setShiftPhase] = useState<number>(0);
  const [moves, setMoves] = useState<number>(0);
  const [shardsCollected, setShardsCollected] = useState<number>(0);
  const [totalShards, setTotalShards] = useState<number>(0);

  // Cumulative Campaign Statistics across all 10 levels
  const [campaignMoves, setCampaignMoves] = useState<number>(0);
  const [campaignShards, setCampaignShards] = useState<number>(0);

  const [gameStatus, setGameStatus] = useState<GameStatus>('PLAYING');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Modals
  const [isRulesOpen, setIsRulesOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);

  // Solvability and hunter distance
  const [isSolvable, setIsSolvable] = useState<boolean>(true);
  const [hunterDistance, setHunterDistance] = useState<number | null>(null);

  // Ref to hold latest state for keyboard handlers
  const stateRef = useRef({
    gameStatus,
    playerPos,
    hunterPos,
    shiftPhase,
    grid,
    currentLevel,
    isRulesOpen,
    isExportOpen
  });

  useEffect(() => {
    stateRef.current = {
      gameStatus,
      playerPos,
      hunterPos,
      shiftPhase,
      grid,
      currentLevel,
      isRulesOpen,
      isExportOpen
    };
  });

  // Count total shards in level
  const initLevel = useCallback((lvlIndex: number) => {
    const lvl = LEVELS[lvlIndex];
    setLevelIdx(lvlIndex);
    const newGrid = lvl.layout.map(r => [...r]);
    setGrid(newGrid);
    setPlayerPos({ ...lvl.playerStart });
    setPrevPlayerPos(null);
    setHunterPos({ ...lvl.hunterStart });
    setPrevHunterPos(null);
    setShiftPhase(0);
    setMoves(0);
    setShardsCollected(0);
    setGameStatus('PLAYING');

    let shards = 0;
    for (let r = 0; r < lvl.height; r++) {
      for (let c = 0; c < lvl.width; c++) {
        if (newGrid[r][c] === TILE_SHARD) shards++;
      }
    }
    setTotalShards(shards);

    // Initial calculations
    const solvable = isMazeSolvable(lvl.playerStart, lvl.exit, newGrid, 0, lvl.shiftCycleLength);
    setIsSolvable(solvable);

    const path = findShortestPath(lvl.hunterStart, lvl.playerStart, newGrid, 0, lvl.shiftCycleLength);
    setHunterDistance(path ? path.length - 1 : null);
  }, []);

  // Initialize level 1 on mount
  useEffect(() => {
    initLevel(0);
  }, [initLevel]);

  // Recalculate distance and solvability whenever positions or phase changes
  useEffect(() => {
    const solvable = isMazeSolvable(playerPos, currentLevel.exit, grid, shiftPhase, currentLevel.shiftCycleLength);
    setIsSolvable(solvable);

    const path = findShortestPath(hunterPos, playerPos, grid, shiftPhase, currentLevel.shiftCycleLength, playerPos, hunterPos);
    setHunterDistance(path ? path.length - 1 : null);
  }, [playerPos, hunterPos, shiftPhase, grid, currentLevel]);

  // Execute a valid player move
  const executeMove = useCallback((dx: number, dy: number) => {
    const { 
      gameStatus: status, 
      playerPos: curP, 
      hunterPos: curH, 
      shiftPhase: curPhase, 
      grid: curGrid, 
      currentLevel: lvl 
    } = stateRef.current;

    if (status !== 'PLAYING') return;

    const nx = curP.x + dx;
    const ny = curP.y + dy;

    // Check bounds
    if (nx < 0 || nx >= lvl.width || ny < 0 || ny >= lvl.height) return;

    const targetTile = curGrid[ny][nx];

    // Check collision with permanent walls or closed gates
    const isOccupiedByEntity = (curH.x === nx && curH.y === ny);
    if (!isTileWalkable(targetTile, curPhase, lvl.shiftCycleLength, isOccupiedByEntity)) {
      return; // Impassable wall/gate; turn is not consumed
    }

    // Step is valid!
    const newPlayerPos = { x: nx, y: ny };
    setPrevPlayerPos({ ...curP });
    setPlayerPos(newPlayerPos);
    const newMoves = moves + 1;
    setMoves(newMoves);
    sound.playStep();

    // Collect Shard if present
    if (targetTile === TILE_SHARD) {
      sound.playShard();
      setShardsCollected(prev => prev + 1);
      setGrid(prevGrid => {
        const updated = prevGrid.map(r => [...r]);
        updated[ny][nx] = TILE_EMPTY;
        return updated;
      });
    }

    // Check Exit detection
    if (newPlayerPos.x === lvl.exit.x && newPlayerPos.y === lvl.exit.y) {
      sound.playWin();
      setGameStatus('LEVEL_WON');
      return;
    }

    // CORE TWIST 1: Maze shifts predefined section!
    const nextPhase = (curPhase + 1) % lvl.shiftCycleLength;
    setShiftPhase(nextPhase);
    sound.playShift();

    // CORE TWIST 2: Hunter takes opportunity to advance
    const nextHunter = getNextHunterMove(curH, newPlayerPos, curGrid, nextPhase, lvl.shiftCycleLength);
    setPrevHunterPos({ ...curH });
    setHunterPos(nextHunter);

    const dist = Math.abs(nextHunter.x - newPlayerPos.x) + Math.abs(nextHunter.y - newPlayerPos.y);
    sound.playHunterStep(dist);

    // Collision check with hunter
    if (nextHunter.x === newPlayerPos.x && nextHunter.y === newPlayerPos.y) {
      sound.playGameOver();
      setGameStatus('GAME_OVER');
    }
  }, [moves]);

  // Wait / Pass turn action
  const executePassTurn = useCallback(() => {
    const { 
      gameStatus: status, 
      playerPos: curP, 
      hunterPos: curH, 
      shiftPhase: curPhase, 
      grid: curGrid, 
      currentLevel: lvl 
    } = stateRef.current;

    if (status !== 'PLAYING') return;

    setMoves(prev => prev + 1);

    // Maze shifts
    const nextPhase = (curPhase + 1) % lvl.shiftCycleLength;
    setShiftPhase(nextPhase);
    sound.playShift();

    // Hunter advances
    const nextHunter = getNextHunterMove(curH, curP, curGrid, nextPhase, lvl.shiftCycleLength);
    setPrevHunterPos({ ...curH });
    setHunterPos(nextHunter);

    const dist = Math.abs(nextHunter.x - curP.x) + Math.abs(nextHunter.y - curP.y);
    sound.playHunterStep(dist);

    if (nextHunter.x === curP.x && nextHunter.y === curP.y) {
      sound.playGameOver();
      setGameStatus('GAME_OVER');
    }
  }, []);

  // Keyboard navigation listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();

      // If a modal is open, Escape closes it
      if (key === 'escape') {
        setIsRulesOpen(false);
        setIsExportOpen(false);
        return;
      }

      if (stateRef.current.isRulesOpen || stateRef.current.isExportOpen) {
        return;
      }

      if (key === 'arrowup' || key === 'w') {
        e.preventDefault();
        executeMove(0, -1);
      } else if (key === 'arrowdown' || key === 's') {
        e.preventDefault();
        executeMove(0, 1);
      } else if (key === 'arrowleft' || key === 'a') {
        e.preventDefault();
        executeMove(-1, 0);
      } else if (key === 'arrowright' || key === 'd') {
        e.preventDefault();
        executeMove(1, 0);
      } else if (key === ' ' || key === 'spacebar') {
        e.preventDefault();
        executePassTurn();
      } else if (key === 'r') {
        e.preventDefault();
        initLevel(levelIdx);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [executeMove, executePassTurn, initLevel, levelIdx]);

  // Click adjacent tile to move
  const handleTileClick = useCallback((pos: Position) => {
    const dx = pos.x - playerPos.x;
    const dy = pos.y - playerPos.y;
    // Only accept direct adjacent 4-way steps
    if (Math.abs(dx) + Math.abs(dy) === 1) {
      executeMove(dx, dy);
    }
  }, [playerPos, executeMove]);

  const handleToggleSound = () => {
    const next = sound.toggle();
    setSoundEnabled(next);
  };

  const handleNextLevel = () => {
    if (levelIdx < LEVELS.length - 1) {
      setCampaignMoves(prev => prev + moves);
      setCampaignShards(prev => prev + shardsCollected);
      initLevel(levelIdx + 1);
    } else {
      // Completed all 10 levels! Reset campaign counters and restart from Level 1
      setCampaignMoves(0);
      setCampaignShards(0);
      initLevel(0);
    }
  };

  const handleRestartLevel = () => {
    initLevel(levelIdx);
  };

  return (
    <div className="min-h-screen bg-[#070913] text-slate-100 flex flex-col justify-between selection:bg-purple-900 selection:text-white">
      {/* Top Header */}
      <Header
        currentLevelId={currentLevel.id}
        totalLevels={LEVELS.length}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
        onSelectLevel={(lvl) => initLevel(lvl - 1)}
        onOpenRules={() => setIsRulesOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
        onRestart={handleRestartLevel}
      />

      {/* Main Game Arena */}
      <main className="flex-1 flex flex-col items-center justify-center p-2 sm:p-4 max-w-5xl mx-auto w-full">
        <HUD
          level={currentLevel}
          totalLevels={LEVELS.length}
          moves={moves}
          shiftPhase={shiftPhase}
          hunterDistance={hunterDistance}
          shardsCollected={shardsCollected}
          totalShards={totalShards}
          isSolvable={isSolvable}
        />

        {/* Board Container */}
        <div className="my-2 sm:my-3 w-full flex justify-center">
          <MazeBoard
            grid={grid}
            width={currentLevel.width}
            height={currentLevel.height}
            playerPos={playerPos}
            prevPlayerPos={prevPlayerPos}
            hunterPos={hunterPos}
            prevHunterPos={prevHunterPos}
            exitPos={currentLevel.exit}
            shiftPhase={shiftPhase}
            cycleLength={currentLevel.shiftCycleLength}
            isGameOver={gameStatus === 'GAME_OVER'}
            isWon={gameStatus === 'LEVEL_WON'}
            onTileClick={handleTileClick}
          />
        </div>

        {/* On-screen Controls & Legend */}
        <Controls
          onMove={executeMove}
          onPassTurn={executePassTurn}
          onRestart={handleRestartLevel}
          disabled={gameStatus !== 'PLAYING'}
        />
      </main>

      {/* Bottom status strip */}
      <footer className="w-full max-w-5xl mx-auto px-4 py-2 text-center text-[11px] text-slate-500 font-mono border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-1">
        <div>ECHO//ESCAPE · Shifting Pixel Maze Prototype</div>
        <div className="flex items-center gap-3">
          <span>Move: <strong className="text-slate-400">WASD / D-Pad</strong></span>
          <span>·</span>
          <span>Shift: <strong className="text-slate-400">Space</strong></span>
          <span>·</span>
          <span>Reset: <strong className="text-slate-400">R</strong></span>
        </div>
      </footer>

      {/* Modals & Overlays */}
      <RulesModal
        isOpen={isRulesOpen}
        onClose={() => setIsRulesOpen(false)}
      />

      <ExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
      />

      <LevelWonModal
        isOpen={gameStatus === 'LEVEL_WON'}
        levelName={currentLevel.name}
        levelId={currentLevel.id}
        totalLevels={LEVELS.length}
        moves={moves}
        parMoves={currentLevel.parMoves}
        shards={shardsCollected}
        totalShards={totalShards}
        totalCampaignMoves={campaignMoves + moves}
        totalCampaignShards={campaignShards + shardsCollected}
        onNextLevel={handleNextLevel}
        onReplay={handleRestartLevel}
      />

      <GameOverModal
        isOpen={gameStatus === 'GAME_OVER'}
        levelName={currentLevel.name}
        moves={moves}
        onRetry={handleRestartLevel}
      />
    </div>
  );
}
