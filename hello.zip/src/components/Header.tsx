import React from 'react';
import { Volume2, VolumeX, BookOpen, Download, RotateCcw } from 'lucide-react';

interface HeaderProps {
  currentLevelId: number;
  totalLevels: number;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onSelectLevel: (lvl: number) => void;
  onOpenRules: () => void;
  onOpenExport: () => void;
  onRestart: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentLevelId,
  totalLevels,
  soundEnabled,
  onToggleSound,
  onSelectLevel,
  onOpenRules,
  onOpenExport,
  onRestart
}) => {
  return (
    <header className="w-full max-w-5xl mx-auto flex items-center justify-between gap-6 px-4 py-3 border-b border-[#1e1b4b] bg-[#090d1a]/80 backdrop-blur-md select-none">
      {/* Zone 1: Brand title single text element */}
      <div className="flex items-center gap-3 shrink-0">
        <a 
          href="#game" 
          className="text-lg md:text-xl font-bold font-pixel tracking-wider text-[#fbbf24] hover:text-[#fef08a] transition-colors whitespace-nowrap text-glow-gold"
        >
          ECHO//ESCAPE
        </a>
      </div>

      {/* Zone 2: Level Navigation Selector */}
      <nav className="flex items-center gap-1">
        {/* Mobile / Compact Stepper */}
        <div className="flex md:hidden items-center gap-1 bg-[#111827] border border-slate-800 rounded px-1.5 py-1">
          <button
            onClick={() => onSelectLevel(Math.max(1, currentLevelId - 1))}
            disabled={currentLevelId <= 1}
            className="px-1.5 py-0.5 text-xs text-slate-400 hover:text-white disabled:opacity-30"
          >
            ◀
          </button>
          <span className="text-xs font-bold text-amber-400 font-mono">
            {currentLevelId}/{totalLevels}
          </span>
          <button
            onClick={() => onSelectLevel(Math.min(totalLevels, currentLevelId + 1))}
            disabled={currentLevelId >= totalLevels}
            className="px-1.5 py-0.5 text-xs text-slate-400 hover:text-white disabled:opacity-30"
          >
            ▶
          </button>
        </div>

        {/* Desktop 10-level Badge Strip */}
        <div className="hidden md:flex items-center gap-1">
          {Array.from({ length: totalLevels }, (_, i) => i + 1).map((lvl) => {
            const isActive = currentLevelId === lvl;
            return (
              <button
                key={lvl}
                onClick={() => onSelectLevel(lvl)}
                title={`Jump to Sector ${lvl}`}
                className={`w-7 h-7 flex items-center justify-center text-xs font-bold font-mono rounded transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-[#312e81] text-[#fbbf24] border border-[#f59e0b] shadow-[0_0_8px_rgba(245,158,11,0.4)]'
                    : 'bg-[#111827] text-slate-400 hover:text-slate-200 hover:bg-[#1f293d] border border-slate-800'
                }`}
              >
                {lvl}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Zone 3: Actions (Restart, Sound, Rules, Export) */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={onRestart}
          title="Restart Level (R)"
          className="p-2 text-slate-400 hover:text-amber-400 bg-[#0f172a] hover:bg-[#1e1b4b] border border-slate-800 rounded transition-colors"
        >
          <RotateCcw className="w-4 h-4" />
        </button>

        <button
          onClick={onToggleSound}
          title={soundEnabled ? "Mute sound" : "Enable sound"}
          className="p-2 text-slate-400 hover:text-cyan-400 bg-[#0f172a] hover:bg-[#1e1b4b] border border-slate-800 rounded transition-colors"
        >
          {soundEnabled ? <Volume2 className="w-4 h-4 text-cyan-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
        </button>

        <button
          onClick={onOpenRules}
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-[#0f172a] hover:bg-[#1e1b4b] border border-slate-800 rounded transition-colors whitespace-nowrap"
        >
          <BookOpen className="w-3.5 h-3.5 text-purple-400" />
          <span>Rules</span>
        </button>

        <button
          onClick={onOpenExport}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-[#070a12] bg-[#f59e0b] hover:bg-[#fbbf24] rounded transition-all shadow-[0_0_12px_rgba(245,158,11,0.3)] whitespace-nowrap"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Code</span>
        </button>
      </div>
    </header>
  );
};
