import React from 'react';
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Hourglass, RotateCcw } from 'lucide-react';

interface ControlsProps {
  onMove: (dx: number, dy: number) => void;
  onPassTurn: () => void;
  onRestart: () => void;
  disabled?: boolean;
}

export const Controls: React.FC<ControlsProps> = ({
  onMove,
  onPassTurn,
  onRestart,
  disabled = false
}) => {
  return (
    <div className="w-full max-w-md mx-auto flex flex-col items-center gap-3 pt-1 select-none">
      {/* Directional Pad */}
      <div className="flex flex-col items-center gap-1.5">
        {/* Up / W */}
        <button
          onClick={() => onMove(0, -1)}
          disabled={disabled}
          className="w-12 h-12 flex flex-col items-center justify-center bg-[#131b2e] hover:bg-[#1e293b] active:bg-[#312e81] border border-[#273552] active:border-amber-400 rounded text-slate-200 transition-all shadow-md active:scale-95 disabled:opacity-40"
          title="Move Up (W or Up Arrow)"
        >
          <ArrowUp className="w-5 h-5 text-amber-400" />
          <span className="text-[9px] font-mono font-bold text-slate-400">W</span>
        </button>

        {/* Left, Down, Right */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => onMove(-1, 0)}
            disabled={disabled}
            className="w-12 h-12 flex flex-col items-center justify-center bg-[#131b2e] hover:bg-[#1e293b] active:bg-[#312e81] border border-[#273552] active:border-amber-400 rounded text-slate-200 transition-all shadow-md active:scale-95 disabled:opacity-40"
            title="Move Left (A or Left Arrow)"
          >
            <ArrowLeft className="w-5 h-5 text-amber-400" />
            <span className="text-[9px] font-mono font-bold text-slate-400">A</span>
          </button>

          <button
            onClick={() => onMove(0, 1)}
            disabled={disabled}
            className="w-12 h-12 flex flex-col items-center justify-center bg-[#131b2e] hover:bg-[#1e293b] active:bg-[#312e81] border border-[#273552] active:border-amber-400 rounded text-slate-200 transition-all shadow-md active:scale-95 disabled:opacity-40"
            title="Move Down (S or Down Arrow)"
          >
            <ArrowDown className="w-5 h-5 text-amber-400" />
            <span className="text-[9px] font-mono font-bold text-slate-400">S</span>
          </button>

          <button
            onClick={() => onMove(1, 0)}
            disabled={disabled}
            className="w-12 h-12 flex flex-col items-center justify-center bg-[#131b2e] hover:bg-[#1e293b] active:bg-[#312e81] border border-[#273552] active:border-amber-400 rounded text-slate-200 transition-all shadow-md active:scale-95 disabled:opacity-40"
            title="Move Right (D or Right Arrow)"
          >
            <ArrowRight className="w-5 h-5 text-amber-400" />
            <span className="text-[9px] font-mono font-bold text-slate-400">D</span>
          </button>
        </div>
      </div>

      {/* Action Row */}
      <div className="flex items-center gap-3 mt-1">
        <button
          onClick={onPassTurn}
          disabled={disabled}
          className="flex items-center gap-1.5 px-4 py-2 bg-[#171e36] hover:bg-[#20294b] active:bg-[#312e81] border border-cyan-800/80 rounded text-xs font-semibold text-cyan-300 transition-all active:scale-95 disabled:opacity-40"
          title="Pass turn: stays in place, shifts the maze, and allows hunter to advance (Spacebar)"
        >
          <Hourglass className="w-3.5 h-3.5 text-cyan-400" />
          <span>Wait / Shift Turn <kbd className="ml-1 px-1 py-0.5 text-[9px] bg-slate-900 border border-slate-700 rounded text-slate-400">Space</kbd></span>
        </button>

        <button
          onClick={onRestart}
          disabled={disabled}
          className="flex items-center gap-1.5 px-3 py-2 bg-[#171e36] hover:bg-[#20294b] active:bg-[#312e81] border border-slate-700 rounded text-xs font-semibold text-slate-300 hover:text-white transition-all active:scale-95 disabled:opacity-40"
          title="Restart Sector (R)"
        >
          <RotateCcw className="w-3.5 h-3.5 text-slate-400" />
          <span>Reset <kbd className="ml-1 px-1 py-0.5 text-[9px] bg-slate-900 border border-slate-700 rounded text-slate-400">R</kbd></span>
        </button>
      </div>

      {/* Micro-Keyboard legend */}
      <div className="flex items-center gap-3 text-[11px] text-slate-500 font-mono">
        <span>Controls: <span className="text-slate-400">WASD</span> or <span className="text-slate-400">Arrows</span></span>
        <span>·</span>
        <span>Shift: <span className="text-slate-400">Space</span></span>
        <span>·</span>
        <span>Restart: <span className="text-slate-400">R</span></span>
      </div>
    </div>
  );
};
