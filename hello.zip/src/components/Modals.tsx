import React, { useState } from 'react';
import { 
  X, 
  Copy, 
  Check, 
  Download, 
  Trophy, 
  Skull, 
  ArrowRight, 
  RotateCcw, 
  Sparkles,
  Zap,
  Info
} from 'lucide-react';
import { generateStandaloneHtml } from '../exportBundle';

interface RulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesModal: React.FC<RulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-[#0b0f1d] border-2 border-[#312e81] rounded-lg p-6 shadow-2xl relative text-slate-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-4">
          <Zap className="w-5 h-5 text-amber-400" />
          <h2 className="text-lg font-bold font-pixel text-[#fbbf24] tracking-wide text-glow-gold">
            RULES OF ENGAGEMENT
          </h2>
        </div>

        <div className="space-y-4 text-xs sm:text-sm text-slate-300 leading-relaxed font-sans">
          <div className="p-3 bg-[#131b2e] border border-slate-800 rounded">
            <h3 className="font-bold text-amber-400 mb-1 flex items-center gap-1.5">
              <span>1. The Shifting Conduits</span>
            </h3>
            <p className="text-slate-300">
              Every valid player move causes the predefined maze sectors to shift state. Conduit <strong className="text-cyan-400">A</strong> and Conduit <strong className="text-purple-400">B</strong> alternate between impassable solid barriers and open corridors.
            </p>
          </div>

          <div className="p-3 bg-[#131b2e] border border-slate-800 rounded">
            <h3 className="font-bold text-cyan-400 mb-1 flex items-center gap-1.5">
              <span>2. Mathematical Solvability Guarantee</span>
            </h3>
            <p className="text-slate-300">
              The maze is engineered with interconnected loops. A path to the golden exit is guaranteed to remain accessible across every phase cycle. Shifting walls will never crush or trap you in your current cell.
            </p>
          </div>

          <div className="p-3 bg-[#131b2e] border border-slate-800 rounded">
            <h3 className="font-bold text-red-400 mb-1 flex items-center gap-1.5">
              <span>3. Relentless Pursuer</span>
            </h3>
            <p className="text-slate-300">
              The shadow Hunter advances 1 step toward you on every move. The Hunter strictly obeys maze walls and cannot phase through closed gates. <strong className="text-amber-300">Strategy:</strong> Time your steps so a gate seals shut behind you, forcing the Hunter into a long detour!
            </p>
          </div>

          <div className="p-3 bg-[#131b2e] border border-slate-800 rounded">
            <h3 className="font-bold text-emerald-400 mb-1 flex items-center gap-1.5">
              <span>4. Controls & Waiting</span>
            </h3>
            <p className="text-slate-300">
              Use <kbd className="px-1 bg-slate-900 border border-slate-700 rounded text-slate-300 font-mono">WASD</kbd> or <kbd className="px-1 bg-slate-900 border border-slate-700 rounded text-slate-300 font-mono">Arrow Keys</kbd> to move. Press <kbd className="px-1 bg-slate-900 border border-slate-700 rounded text-slate-300 font-mono">Space</kbd> to stay in place, shifting the maze while the Hunter steps. Press <kbd className="px-1 bg-slate-900 border border-slate-700 rounded text-slate-300 font-mono">R</kbd> to quickly restart the sector.
            </p>
          </div>
        </div>

        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 rounded transition-colors"
          >
            ENTER THE MAZE
          </button>
        </div>
      </div>
    </div>
  );
};

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExportModal: React.FC<ExportModalProps> = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const standaloneHtml = generateStandaloneHtml();

  const handleCopy = () => {
    navigator.clipboard.writeText(standaloneHtml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([standaloneHtml], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'echo_escape.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-2xl bg-[#0b0f1d] border-2 border-[#f59e0b] rounded-lg p-6 shadow-2xl relative text-slate-200 max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-2">
          <Download className="w-5 h-5 text-amber-400" />
          <h2 className="text-lg font-bold font-pixel text-[#fbbf24] tracking-wide">
            COMPETITION EXPORT PACK
          </h2>
        </div>

        <p className="text-xs text-slate-400 mb-4">
          Export ECHO//ESCAPE as a single self-contained HTML/CSS/JS file with zero external dependencies, 100% offline ready for competition judges.
        </p>

        {/* How to use info */}
        <div className="bg-[#111827] border border-slate-800 rounded p-3 mb-4 text-xs space-y-2 text-slate-300 font-sans">
          <div className="flex items-start gap-2">
            <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-100">Zero Dependencies & Instant Execution:</strong>
              <p className="text-slate-400 mt-0.5">
                The exported bundle contains the complete game engine, 3 handcrafted levels, Web Audio API 8-bit sound synth, BFS solver, and pixel renderer in a single <code className="text-amber-300">echo_escape.html</code> file. Double-click to play in any modern browser!
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-3 mb-4">
          <button
            onClick={handleDownload}
            className="flex items-center gap-2 px-4 py-2 text-xs font-bold bg-[#f59e0b] hover:bg-[#fbbf24] text-slate-950 rounded transition-all shadow-[0_0_12px_rgba(245,158,11,0.3)]"
          >
            <Download className="w-4 h-4" />
            <span>Download echo_escape.html</span>
          </button>

          <button
            onClick={handleCopy}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold bg-[#1e1b4b] hover:bg-[#312e81] border border-[#4338ca] text-indigo-200 rounded transition-colors"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied to Clipboard!' : 'Copy Raw HTML Source'}</span>
          </button>
        </div>

        {/* Code Preview Preview box */}
        <div className="flex-1 overflow-hidden flex flex-col border border-slate-800 rounded bg-[#070a12]">
          <div className="px-3 py-1.5 bg-[#0e1424] border-b border-slate-800 text-[11px] font-mono text-slate-400 flex justify-between items-center">
            <span>echo_escape.html (Standalone Bundle · ~12 KB)</span>
            <span className="text-emerald-400 font-mono">100% Offline Compatible</span>
          </div>
          <pre className="flex-1 p-3 text-[11px] font-mono text-slate-400 overflow-y-auto whitespace-pre selection:bg-indigo-900 selection:text-white">
            {standaloneHtml.slice(0, 1800)}...
            {'\n/* [Full source code embedded cleanly inside bundle] */'}
          </pre>
        </div>

        <div className="mt-4 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-medium text-slate-400 hover:text-white transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

interface LevelWonModalProps {
  isOpen: boolean;
  levelName: string;
  levelId: number;
  totalLevels: number;
  moves: number;
  parMoves: number;
  shards: number;
  totalShards: number;
  totalCampaignMoves?: number;
  totalCampaignShards?: number;
  onNextLevel: () => void;
  onReplay: () => void;
}

export const LevelWonModal: React.FC<LevelWonModalProps> = ({
  isOpen,
  levelName,
  levelId,
  totalLevels,
  moves,
  parMoves,
  shards,
  totalShards,
  totalCampaignMoves = moves,
  totalCampaignShards = shards,
  onNextLevel,
  onReplay,
}) => {
  if (!isOpen) return null;

  const isParMet = moves <= parMoves;
  const isAllShards = shards === totalShards;
  const stars = isParMet && isAllShards ? 3 : (isParMet || isAllShards ? 2 : 1);
  const isFinalLevel = levelId >= totalLevels;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in zoom-in-95 duration-200 select-none">
      <div className="w-full max-w-md bg-[#0b0f1d] border-2 border-amber-400 rounded-lg p-6 shadow-[0_0_50px_rgba(245,158,11,0.25)] text-center text-slate-100">
        <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-400">
          <Trophy className="w-6 h-6 animate-bounce" />
        </div>

        <h2 className="text-xl font-bold font-pixel text-amber-400 tracking-wide text-glow-gold mb-1">
          {isFinalLevel ? 'ALL 10 SECTORS ESCAPED!' : `SECTOR ${levelId} ESCAPED!`}
        </h2>
        <p className="text-xs text-slate-400 font-mono mb-4">
          {isFinalLevel ? 'MASTER PROTOCOL COMPLETE // LABYRINTH CONQUERED' : levelName}
        </p>

        {/* Stars */}
        <div className="flex justify-center gap-2 mb-4 text-xl">
          <span className={stars >= 1 ? 'text-amber-400' : 'text-slate-700'}>★</span>
          <span className={stars >= 2 ? 'text-amber-400' : 'text-slate-700'}>★</span>
          <span className={stars >= 3 ? 'text-amber-400' : 'text-slate-700'}>★</span>
        </div>

        {/* Scorecard */}
        <div className="bg-[#111827] border border-slate-800 rounded p-4 mb-4 grid grid-cols-2 gap-4 text-left">
          <div>
            <div className="text-[10px] text-slate-400 uppercase font-mono">Moves This Sector</div>
            <div className="text-base font-bold font-mono text-slate-100">
              {moves} <span className="text-xs text-slate-500 font-normal">/ {parMoves} par</span>
            </div>
          </div>
          <div>
            <div className="text-[10px] text-slate-400 uppercase font-mono">Relics Retrieved</div>
            <div className="text-base font-bold font-mono text-amber-400">
              {shards} / {totalShards}
            </div>
          </div>
        </div>

        {/* If Final Level: Show Full 10-Level Campaign Summary */}
        {isFinalLevel && (
          <div className="bg-[#17132a] border border-purple-800/80 rounded p-3 mb-5 text-xs text-purple-200 font-mono flex justify-around">
            <div>
              <div className="text-[10px] text-slate-400 uppercase">Total Campaign Moves</div>
              <div className="text-sm font-bold text-white mt-0.5">{totalCampaignMoves}</div>
            </div>
            <div>
              <div className="text-[10px] text-slate-400 uppercase">Total Relics Found</div>
              <div className="text-sm font-bold text-amber-300 mt-0.5">{totalCampaignShards}</div>
            </div>
          </div>
        )}

        {/* CTA Buttons */}
        <div className="flex items-center justify-center gap-3">
          <button
            onClick={onReplay}
            className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-semibold bg-[#1e1b4b] hover:bg-[#312e81] border border-slate-700 rounded text-slate-200 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Replay Sector</span>
          </button>

          <button
            onClick={onNextLevel}
            className="flex items-center gap-2 px-6 py-2.5 text-xs font-bold bg-[#f59e0b] hover:bg-[#fbbf24] text-slate-950 rounded transition-all shadow-md font-mono"
          >
            <span>{isFinalLevel ? 'Play Again (Sector 1)' : `Continue to Sector ${levelId + 1}`}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

interface GameOverModalProps {
  isOpen: boolean;
  levelName: string;
  moves: number;
  onRetry: () => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  isOpen,
  levelName,
  moves,
  onRetry,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm animate-in zoom-in-95 duration-200 select-none">
      <div className="w-full max-w-md bg-[#0e0712] border-2 border-red-500 rounded-lg p-6 shadow-[0_0_50px_rgba(239,68,68,0.3)] text-center text-slate-100">
        <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-red-950/80 border border-red-500 flex items-center justify-center text-red-500">
          <Skull className="w-6 h-6 animate-pulse" />
        </div>

        <h2 className="text-xl font-bold font-pixel text-red-500 tracking-wide text-glow-red mb-1">
          CAUGHT BY THE SHADOW
        </h2>
        <p className="text-xs text-slate-400 font-mono mb-4">{levelName}</p>

        <p className="text-xs text-slate-300 leading-relaxed mb-6 max-w-xs mx-auto">
          The Hunter caught your echo. Every move reconfigures the corridors—time your shifts to isolate the pursuer.
        </p>

        <div className="bg-[#1a0f1e] border border-red-950 rounded p-3 mb-6 inline-block font-mono text-xs text-red-300">
          SURVIVED <span className="font-bold text-white text-sm">{moves}</span> STEPS
        </div>

        <div className="flex justify-center">
          <button
            onClick={onRetry}
            className="flex items-center gap-2 px-6 py-2.5 text-xs font-bold bg-red-600 hover:bg-red-500 text-white rounded transition-all shadow-[0_0_15px_rgba(239,68,68,0.4)]"
          >
            <RotateCcw className="w-4 h-4" />
            <span>TRY AGAIN (R)</span>
          </button>
        </div>
      </div>
    </div>
  );
};
