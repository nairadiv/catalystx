import React, { useEffect, useRef, useState } from 'react';
import { Position } from '../types';
import { 
  TILE_WALL, 
  TILE_GATE_ALPHA, 
  TILE_GATE_BETA, 
  TILE_GATE_GAMMA, 
  TILE_SHARD, 
  TILE_EXIT,
  isTileWalkable,
  findShortestPath
} from '../pathfinding';

interface MazeBoardProps {
  grid: number[][];
  width: number;
  height: number;
  playerPos: Position;
  prevPlayerPos: Position | null;
  hunterPos: Position;
  prevHunterPos: Position | null;
  exitPos: Position;
  shiftPhase: number;
  cycleLength: number;
  isGameOver: boolean;
  isWon: boolean;
  onTileClick?: (pos: Position) => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  life: number;
  maxLife: number;
}

interface EchoTrail {
  x: number;
  y: number;
  alpha: number;
}

export const MazeBoard: React.FC<MazeBoardProps> = ({
  grid,
  width,
  height,
  playerPos,
  prevPlayerPos,
  hunterPos,
  prevHunterPos,
  exitPos,
  shiftPhase,
  cycleLength,
  isGameOver,
  isWon,
  onTileClick
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Animation states
  const [animProgress, setAnimProgress] = useState(1);
  const trailsRef = useRef<EchoTrail[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const frameRef = useRef<number>(0);
  const startTimeRef = useRef<number>(Date.now());

  // Record echo trail when player moves
  useEffect(() => {
    if (prevPlayerPos && (prevPlayerPos.x !== playerPos.x || prevPlayerPos.y !== playerPos.y)) {
      trailsRef.current.push({
        x: prevPlayerPos.x,
        y: prevPlayerPos.y,
        alpha: 0.7
      });
      // Keep at most 8 echo trails
      if (trailsRef.current.length > 8) {
        trailsRef.current.shift();
      }
      setAnimProgress(0);
    }
  }, [playerPos, prevPlayerPos]);

  // Main animation and render loop
  useEffect(() => {
    let lastTime = performance.now();

    const loop = (currentTime: number) => {
      const dt = (currentTime - lastTime) / 1000;
      lastTime = currentTime;

      // Progress movement interpolation
      setAnimProgress((prev) => {
        if (prev < 1) {
          return Math.min(1, prev + dt * 10); // ~100ms smooth step
        }
        return 1;
      });

      // Update echo trails
      trailsRef.current.forEach((t) => {
        t.alpha = Math.max(0, t.alpha - dt * 0.4);
      });
      trailsRef.current = trailsRef.current.filter((t) => t.alpha > 0.05);

      // Spawn portal particles
      if (Math.random() < 0.3) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 0.5 + Math.random() * 0.8;
        particlesRef.current.push({
          x: exitPos.x + 0.5,
          y: exitPos.y + 0.5,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          color: '#fbbf24',
          size: 1.5 + Math.random() * 2,
          alpha: 0.9,
          life: 0,
          maxLife: 0.6 + Math.random() * 0.4
        });
      }

      // Spawn hunter shadow particles
      if (Math.random() < 0.25) {
        particlesRef.current.push({
          x: hunterPos.x + 0.3 + Math.random() * 0.4,
          y: hunterPos.y + 0.3 + Math.random() * 0.4,
          vx: (Math.random() - 0.5) * 0.3,
          vy: -0.4 - Math.random() * 0.4,
          color: '#ef4444',
          size: 1 + Math.random() * 2,
          alpha: 0.7,
          life: 0,
          maxLife: 0.5
        });
      }

      // Update particles
      particlesRef.current.forEach((p) => {
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.life += dt;
        p.alpha = Math.max(0, 1 - p.life / p.maxLife);
      });
      particlesRef.current = particlesRef.current.filter((p) => p.life < p.maxLife);

      draw();
      frameRef.current = requestAnimationFrame(loop);
    };

    frameRef.current = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(frameRef.current);
    };
  }, [grid, width, height, playerPos, prevPlayerPos, hunterPos, prevHunterPos, exitPos, shiftPhase, cycleLength, isGameOver, isWon]);

  const draw = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Viewport resolution
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const targetW = Math.floor(rect.width * dpr);
    const targetH = Math.floor(rect.height * dpr);

    if (canvas.width !== targetW || canvas.height !== targetH) {
      canvas.width = targetW;
      canvas.height = targetH;
    }

    ctx.save();
    ctx.scale(dpr, dpr);

    const boardWidth = rect.width;
    const boardHeight = rect.height;
    const tileSize = Math.min(boardWidth / width, boardHeight / height);
    const offsetX = (boardWidth - tileSize * width) / 2;
    const offsetY = (boardHeight - tileSize * height) / 2;

    const time = (Date.now() - startTimeRef.current) / 1000;

    // Clear background: Deep void navy
    ctx.fillStyle = '#080c16';
    ctx.fillRect(0, 0, boardWidth, boardHeight);

    // 1. Draw Grid Tiles
    for (let r = 0; r < height; r++) {
      for (let c = 0; c < width; c++) {
        const tile = grid[r]?.[c] ?? TILE_WALL;
        const x = offsetX + c * tileSize;
        const y = offsetY + r * tileSize;

        // Floor base
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(x, y, tileSize, tileSize);

        // Subtle floor grain / brick line
        ctx.strokeStyle = 'rgba(30, 41, 59, 0.4)';
        ctx.lineWidth = 1;
        ctx.strokeRect(x + 0.5, y + 0.5, tileSize - 1, tileSize - 1);

        if (tile === TILE_WALL) {
          // Basalt stone wall block
          ctx.fillStyle = '#171c35';
          ctx.fillRect(x, y, tileSize, tileSize);

          // Top/Left bevel highlight (light navy/purple)
          ctx.fillStyle = '#272f55';
          ctx.fillRect(x, y, tileSize, 2);
          ctx.fillRect(x, y, 2, tileSize);

          // Bottom/Right bevel shadow (deep dark)
          ctx.fillStyle = '#0a0d18';
          ctx.fillRect(x, y + tileSize - 2, tileSize, 2);
          ctx.fillRect(x + tileSize - 2, y, 2, tileSize);

          // Inner stone texture accent
          ctx.fillStyle = '#1e2547';
          ctx.fillRect(x + tileSize * 0.3, y + tileSize * 0.3, tileSize * 0.4, tileSize * 0.4);
        } else if (tile === TILE_GATE_ALPHA) {
          // Gate Alpha (shifts between solid and open)
          const isOccupied = (playerPos.x === c && playerPos.y === r) || (hunterPos.x === c && hunterPos.y === r);
          const isSolid = !isTileWalkable(tile, shiftPhase, cycleLength, isOccupied);

          if (isSolid) {
            // Solid barrier: Radiant Cyan Wall
            ctx.fillStyle = '#083344';
            ctx.fillRect(x, y, tileSize, tileSize);
            ctx.fillStyle = '#0e7490';
            ctx.fillRect(x + 2, y + 2, tileSize - 4, tileSize - 4);
            
            // Cyan border glow
            ctx.strokeStyle = '#06b6d4';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(x + 2.5, y + 2.5, tileSize - 5, tileSize - 5);

            // Gate Alpha rune symbol 'A'
            ctx.fillStyle = '#cffafe';
            ctx.font = `bold ${Math.max(10, Math.floor(tileSize * 0.45))}px monospace`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('A', x + tileSize / 2, y + tileSize / 2);
          } else {
            // Open state: Ethereal cyan floor beacon
            ctx.fillStyle = 'rgba(6, 182, 212, 0.12)';
            ctx.fillRect(x, y, tileSize, tileSize);
            ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
            ctx.setLineDash([2, 2]);
            ctx.strokeRect(x + 3, y + 3, tileSize - 6, tileSize - 6);
            ctx.setLineDash([]);

            ctx.fillStyle = 'rgba(6, 182, 212, 0.6)';
            ctx.font = `${Math.max(8, Math.floor(tileSize * 0.32))}px monospace`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('a', x + tileSize / 2, y + tileSize / 2);
          }
        } else if (tile === TILE_GATE_BETA) {
          // Gate Beta (shifts state)
          const isOccupied = (playerPos.x === c && playerPos.y === r) || (hunterPos.x === c && hunterPos.y === r);
          const isSolid = !isTileWalkable(tile, shiftPhase, cycleLength, isOccupied);

          if (isSolid) {
            // Solid barrier: Deep Purple / Violet Wall
            ctx.fillStyle = '#2e1065';
            ctx.fillRect(x, y, tileSize, tileSize);
            ctx.fillStyle = '#6b21a8';
            ctx.fillRect(x + 2, y + 2, tileSize - 4, tileSize - 4);

            // Violet border glow
            ctx.strokeStyle = '#a855f7';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(x + 2.5, y + 2.5, tileSize - 5, tileSize - 5);

            // Gate Beta rune symbol 'B'
            ctx.fillStyle = '#f3e8ff';
            ctx.font = `bold ${Math.max(10, Math.floor(tileSize * 0.45))}px monospace`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('B', x + tileSize / 2, y + tileSize / 2);
          } else {
            // Open state: Ethereal violet floor beacon
            ctx.fillStyle = 'rgba(168, 85, 247, 0.12)';
            ctx.fillRect(x, y, tileSize, tileSize);
            ctx.strokeStyle = 'rgba(168, 85, 247, 0.4)';
            ctx.setLineDash([2, 2]);
            ctx.strokeRect(x + 3, y + 3, tileSize - 6, tileSize - 6);
            ctx.setLineDash([]);

            ctx.fillStyle = 'rgba(168, 85, 247, 0.6)';
            ctx.font = `${Math.max(8, Math.floor(tileSize * 0.32))}px monospace`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('b', x + tileSize / 2, y + tileSize / 2);
          }
        } else if (tile === TILE_GATE_GAMMA) {
          // Gate Gamma
          const isOccupied = (playerPos.x === c && playerPos.y === r) || (hunterPos.x === c && hunterPos.y === r);
          const isSolid = !isTileWalkable(tile, shiftPhase, cycleLength, isOccupied);

          if (isSolid) {
            ctx.fillStyle = '#451a03';
            ctx.fillRect(x, y, tileSize, tileSize);
            ctx.fillStyle = '#b45309';
            ctx.fillRect(x + 2, y + 2, tileSize - 4, tileSize - 4);
            ctx.strokeStyle = '#f59e0b';
            ctx.lineWidth = 1.5;
            ctx.strokeRect(x + 2.5, y + 2.5, tileSize - 5, tileSize - 5);

            ctx.fillStyle = '#fef3c7';
            ctx.font = `bold ${Math.max(10, Math.floor(tileSize * 0.45))}px monospace`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('C', x + tileSize / 2, y + tileSize / 2);
          } else {
            ctx.fillStyle = 'rgba(245, 158, 11, 0.12)';
            ctx.fillRect(x, y, tileSize, tileSize);
            ctx.strokeStyle = 'rgba(245, 158, 11, 0.4)';
            ctx.setLineDash([2, 2]);
            ctx.strokeRect(x + 3, y + 3, tileSize - 6, tileSize - 6);
            ctx.setLineDash([]);

            ctx.fillStyle = 'rgba(245, 158, 11, 0.6)';
            ctx.font = `${Math.max(8, Math.floor(tileSize * 0.32))}px monospace`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText('c', x + tileSize / 2, y + tileSize / 2);
          }
        } else if (tile === TILE_SHARD) {
          // Golden Relic / Shard
          const cx = x + tileSize / 2;
          const cy = y + tileSize / 2 + Math.sin(time * 4) * 2;
          const s = tileSize * 0.24;

          // Glowing halo
          const halo = ctx.createRadialGradient(cx, cy, 2, cx, cy, tileSize * 0.4);
          halo.addColorStop(0, 'rgba(251, 191, 36, 0.6)');
          halo.addColorStop(1, 'rgba(251, 191, 36, 0)');
          ctx.fillStyle = halo;
          ctx.beginPath();
          ctx.arc(cx, cy, tileSize * 0.4, 0, Math.PI * 2);
          ctx.fill();

          // Diamond shape
          ctx.fillStyle = '#fbbf24';
          ctx.beginPath();
          ctx.moveTo(cx, cy - s);
          ctx.lineTo(cx + s * 0.7, cy);
          ctx.lineTo(cx, cy + s);
          ctx.lineTo(cx - s * 0.7, cy);
          ctx.closePath();
          ctx.fill();

          ctx.fillStyle = '#fff';
          ctx.beginPath();
          ctx.arc(cx - s * 0.2, cy - s * 0.2, s * 0.2, 0, Math.PI * 2);
          ctx.fill();
        }

        // Exit Portal
        if (r === exitPos.y && c === exitPos.x) {
          const cx = x + tileSize / 2;
          const cy = y + tileSize / 2;

          // Pulsing portal aura
          const pulse = (Math.sin(time * 3) + 1) * 0.5;
          const auraRadius = tileSize * (0.42 + pulse * 0.1);
          const aura = ctx.createRadialGradient(cx, cy, 2, cx, cy, auraRadius);
          aura.addColorStop(0, 'rgba(251, 191, 36, 0.85)');
          aura.addColorStop(0.6, 'rgba(217, 119, 6, 0.4)');
          aura.addColorStop(1, 'rgba(245, 158, 11, 0)');
          ctx.fillStyle = aura;
          ctx.beginPath();
          ctx.arc(cx, cy, auraRadius, 0, Math.PI * 2);
          ctx.fill();

          // Golden Portal Arch
          ctx.fillStyle = '#d97706';
          ctx.fillRect(x + 4, y + 4, tileSize - 8, tileSize - 8);
          ctx.fillStyle = '#fbbf24';
          ctx.fillRect(x + 6, y + 6, tileSize - 12, tileSize - 12);
          ctx.fillStyle = '#070a12';
          ctx.fillRect(x + 8, y + 9, tileSize - 16, tileSize - 13);

          // Star glyph in center
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(cx - 1.5, cy - 1.5, 3, 3);
        }
      }
    }

    // 2. Draw Echo Trails (Player's past steps)
    trailsRef.current.forEach((trail) => {
      const tx = offsetX + trail.x * tileSize + tileSize / 2;
      const ty = offsetY + trail.y * tileSize + tileSize / 2;

      ctx.fillStyle = `rgba(245, 158, 11, ${trail.alpha * 0.4})`;
      ctx.beginPath();
      ctx.arc(tx, ty, tileSize * 0.2, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = `rgba(245, 158, 11, ${trail.alpha * 0.6})`;
      ctx.lineWidth = 1;
      ctx.strokeRect(
        offsetX + trail.x * tileSize + tileSize * 0.3,
        offsetY + trail.y * tileSize + tileSize * 0.3,
        tileSize * 0.4,
        tileSize * 0.4
      );
    });

    // 3. Draw Particles (Portal and Hunter shadows)
    particlesRef.current.forEach((p) => {
      const px = offsetX + p.x * tileSize;
      const py = offsetY + p.y * tileSize;
      ctx.fillStyle = p.color;
      ctx.globalAlpha = p.alpha;
      ctx.beginPath();
      ctx.arc(px, py, p.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    });

    // 4. Interpolate and Draw Hunter
    let curHx = hunterPos.x;
    let curHy = hunterPos.y;
    if (prevHunterPos && animProgress < 1) {
      curHx = prevHunterPos.x + (hunterPos.x - prevHunterPos.x) * animProgress;
      curHy = prevHunterPos.y + (hunterPos.y - prevHunterPos.y) * animProgress;
    }

    const hScreenX = offsetX + curHx * tileSize;
    const hScreenY = offsetY + curHy * tileSize;
    const hMargin = Math.max(3, Math.floor(tileSize * 0.15));

    // Hunter danger glow
    const hGlow = ctx.createRadialGradient(
      hScreenX + tileSize / 2, 
      hScreenY + tileSize / 2, 
      2, 
      hScreenX + tileSize / 2, 
      hScreenY + tileSize / 2, 
      tileSize * 0.7
    );
    hGlow.addColorStop(0, 'rgba(239, 68, 68, 0.45)');
    hGlow.addColorStop(1, 'rgba(239, 68, 68, 0)');
    ctx.fillStyle = hGlow;
    ctx.beginPath();
    ctx.arc(hScreenX + tileSize / 2, hScreenY + tileSize / 2, tileSize * 0.7, 0, Math.PI * 2);
    ctx.fill();

    // Hunter Body: Crimson void shadow with jagged pixel cape
    ctx.fillStyle = '#450a0a';
    ctx.fillRect(hScreenX + hMargin, hScreenY + hMargin, tileSize - hMargin * 2, tileSize - hMargin * 2);

    ctx.fillStyle = '#991b1b';
    ctx.fillRect(hScreenX + hMargin + 2, hScreenY + hMargin + 2, tileSize - hMargin * 2 - 4, tileSize - hMargin * 2 - 4);

    // Glowing hunter eyes
    const eyeSize = Math.max(2, Math.floor(tileSize * 0.12));
    const eyeY = hScreenY + tileSize * 0.35;
    ctx.fillStyle = '#fca5a5';
    ctx.fillRect(hScreenX + tileSize * 0.3, eyeY, eyeSize, eyeSize);
    ctx.fillRect(hScreenX + tileSize * 0.7 - eyeSize, eyeY, eyeSize, eyeSize);

    // Inner menacing ruby pupils
    ctx.fillStyle = '#ef4444';
    ctx.fillRect(hScreenX + tileSize * 0.3 + 1, eyeY, eyeSize - 1, eyeSize - 1);
    ctx.fillRect(hScreenX + tileSize * 0.7 - eyeSize + 1, eyeY, eyeSize - 1, eyeSize - 1);

    // 5. Interpolate and Draw Player
    let curPx = playerPos.x;
    let curPy = playerPos.y;
    if (prevPlayerPos && animProgress < 1) {
      curPx = prevPlayerPos.x + (playerPos.x - prevPlayerPos.x) * animProgress;
      curPy = prevPlayerPos.y + (playerPos.y - prevPlayerPos.y) * animProgress;
    }

    const pScreenX = offsetX + curPx * tileSize;
    const pScreenY = offsetY + curPy * tileSize;
    const pMargin = Math.max(3, Math.floor(tileSize * 0.14));

    // Player Golden Echo Aura
    const pGlow = ctx.createRadialGradient(
      pScreenX + tileSize / 2, 
      pScreenY + tileSize / 2, 
      2, 
      pScreenX + tileSize / 2, 
      pScreenY + tileSize / 2, 
      tileSize * 0.65
    );
    pGlow.addColorStop(0, 'rgba(251, 191, 36, 0.45)');
    pGlow.addColorStop(1, 'rgba(251, 191, 36, 0)');
    ctx.fillStyle = pGlow;
    ctx.beginPath();
    ctx.arc(pScreenX + tileSize / 2, pScreenY + tileSize / 2, tileSize * 0.65, 0, Math.PI * 2);
    ctx.fill();

    // Player Base: Golden Knight/Explorer silhouette
    ctx.fillStyle = '#b45309';
    ctx.fillRect(pScreenX + pMargin, pScreenY + pMargin, tileSize - pMargin * 2, tileSize - pMargin * 2);

    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(pScreenX + pMargin + 2, pScreenY + pMargin + 2, tileSize - pMargin * 2 - 4, tileSize - pMargin * 2 - 4);

    // Golden Visor / Crown crest
    ctx.fillStyle = '#fef08a';
    ctx.fillRect(pScreenX + pMargin + 3, pScreenY + pMargin + 3, tileSize - pMargin * 2 - 6, Math.max(2, tileSize * 0.18));

    // Twin observant eyes
    const pEyeSize = Math.max(2, Math.floor(tileSize * 0.11));
    const pEyeY = pScreenY + tileSize * 0.42;
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(pScreenX + tileSize * 0.32, pEyeY, pEyeSize, pEyeSize);
    ctx.fillRect(pScreenX + tileSize * 0.68 - pEyeSize, pEyeY, pEyeSize, pEyeSize);

    // Subtle line of sight / distance pulse if hunter is near (≤ 4 tiles)
    const directDist = Math.abs(playerPos.x - hunterPos.x) + Math.abs(playerPos.y - hunterPos.y);
    if (directDist <= 4) {
      ctx.strokeStyle = `rgba(239, 68, 68, ${0.4 + Math.sin(time * 6) * 0.25})`;
      ctx.lineWidth = 1.5;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(pScreenX + tileSize / 2, pScreenY + tileSize / 2);
      ctx.lineTo(hScreenX + tileSize / 2, hScreenY + tileSize / 2);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    ctx.restore();
  };

  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!onTileClick || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const tileSize = Math.min(rect.width / width, rect.height / height);
    const offsetX = (rect.width - tileSize * width) / 2;
    const offsetY = (rect.height - tileSize * height) / 2;

    const col = Math.floor((x - offsetX) / tileSize);
    const row = Math.floor((y - offsetY) / tileSize);

    if (col >= 0 && col < width && row >= 0 && row < height) {
      onTileClick({ x: col, y: row });
    }
  };

  return (
    <div 
      ref={containerRef} 
      className="relative w-full max-w-[min(500px,calc(100vh-310px))] aspect-square mx-auto flex items-center justify-center p-2 bg-[#060913] border-2 border-[#1e1b4b] rounded-lg shadow-[0_0_40px_rgba(49,46,129,0.3)] select-none"
    >
      <canvas
        ref={canvasRef}
        onClick={handleCanvasClick}
        className="w-full h-full block pixelated rounded cursor-pointer"
        style={{ touchAction: 'none' }}
      />
    </div>
  );
};
