import React from 'react';
import { ShieldCheck, Flame, Compass, Zap } from 'lucide-react';
import { LevelData } from '../types';

interface HUDProps {
  level: LevelData;
  totalLevels?: number;
  moves: number;
  shiftPhase: number;
  hunterDistance: number | null; // null if hunter path is blocked
  shardsCollected: number;
  totalShards: number;
  isSolvable: boolean;
}

export const HUD: React.FC<HUDProps> = ({
  level,
  totalLevels = 10,
  moves,
  shiftPhase,
  hunterDistance,
  shardsCollected,
  totalShards,
  isSolvable,
}) => {
  // Threat assessment
  const isHunterBlocked = hunterDistance === null;
  const threatColor = isHunterBlocked 
    ? 'text-cyan-400 border-cyan-800 bg-cyan-950/30' 
    : hunterDistance <= 3 
      ? 'text-red-400 border-red-800 bg-red-950/40 animate-pulse' 
      : hunterDistance <= 6 
        ? 'text-amber-400 border-amber-800 bg-amber-950/30' 
        : 'text-emerald-400 border-emerald-900 bg-emerald-950/20';

  const threatText = isHunterBlocked
    ? 'HUNTER CONTAINED BEHIND SHIFT GATE'
    : hunterDistance <= 3
      ? `IMMINENT DANGER: ${hunterDistance} STEPS AWAY`
      : hunterDistance <= 6
        ? `ALERT: PURSUER ${hunterDistance} STEPS AWAY`
        : `STALKING: ${hunterDistance} STEPS AWAY`;

  const progressPercent = Math.round((level.id / totalLevels) * 100);

  return (
    <div className="w-full max-w-5xl mx-auto px-4 py-2 flex flex-col gap-2 select-none">
      {/* Top Banner: Level Title, LEVEL: X/10 badge, Progress bar & Lore */}
      <div className="flex flex-col gap-1.5 border-b border-slate-800/80 pb-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="px-2 py-0.5 rounded bg-amber-500/20 border border-amber-400/80 text-[#fbbf24] font-pixel text-[11px] tracking-wider">
              LEVEL: {level.id}/{totalLevels}
            </span>
            <h2 className="text-sm sm:text-base font-bold text-slate-100 flex items-center gap-2">
              <span>{level.name}</span>
              <span className="text-xs text-slate-400 font-mono">[{level.subtitle}]</span>
            </h2>
          </div>

          {/* Path Solvability Guarantee */}
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#0b1329] border border-indigo-900/60 text-xs text-indigo-300">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-mono text-[11px]">
                {isSolvable ? 'SOLVABLE' : 'CALCULATING'}
              </span>
            </div>
          </div>
        </div>

        {/* Progress bar across 10 levels */}
        <div className="w-full flex items-center gap-2">
          <div className="flex-1 h-1.5 bg-[#0f172a] rounded-full overflow-hidden border border-slate-800">
            <div 
              className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-amber-400 transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <span className="text-[10px] font-mono text-slate-400 whitespace-nowrap">
            {progressPercent}% Complete
          </span>
        </div>
      </div>

      {/* Main HUD Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        {/* Metric 1: Moves & Par */}
        <div className="bg-[#0b0f1d] border border-slate-800/80 rounded p-2.5 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Moves Taken</div>
            <div className="text-lg font-bold text-slate-100 font-mono tabular-nums">
              {moves} <span className="text-xs text-slate-500 font-normal">/ {level.parMoves} par</span>
            </div>
          </div>
          <Compass className="w-5 h-5 text-amber-500/60" />
        </div>

        {/* Metric 2: Shift Phase & Conduits */}
        <div className="bg-[#0b0f1d] border border-slate-800/80 rounded p-2.5 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Conduit Cycle</div>
            <div className="text-sm font-bold font-mono flex items-center gap-2 mt-0.5">
              <span className="text-cyan-400">Phase {shiftPhase + 1}/{level.shiftCycleLength}</span>
              <div className="flex items-center gap-1 text-[11px]">
                <span className={`px-1 rounded ${shiftPhase === 0 ? 'bg-cyan-900/80 text-cyan-200 border border-cyan-500' : 'bg-slate-800 text-slate-400'}`}>
                  A
                </span>
                <span className={`px-1 rounded ${shiftPhase === 1 ? 'bg-purple-900/80 text-purple-200 border border-purple-500' : 'bg-slate-800 text-slate-400'}`}>
                  B
                </span>
                {level.shiftCycleLength === 3 && (
                  <span className={`px-1 rounded ${shiftPhase === 2 ? 'bg-amber-900/80 text-amber-200 border border-amber-500' : 'bg-slate-800 text-slate-400'}`}>
                    C
                  </span>
                )}
              </div>
            </div>
          </div>
          <Zap className="w-5 h-5 text-cyan-500/60" />
        </div>

        {/* Metric 3: Relic Shards */}
        <div className="bg-[#0b0f1d] border border-slate-800/80 rounded p-2.5 flex items-center justify-between">
          <div>
            <div className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Relics Found</div>
            <div className="text-lg font-bold text-[#fbbf24] font-mono tabular-nums">
              {shardsCollected} <span className="text-xs text-slate-500 font-normal">/ {totalShards}</span>
            </div>
          </div>
          <div className="w-4 h-4 bg-amber-400/80 rounded-sm rotate-45 border border-amber-300" />
        </div>

        {/* Metric 4: Hunter Threat Proximity */}
        <div className={`border rounded p-2.5 flex items-center justify-between transition-colors ${threatColor}`}>
          <div className="overflow-hidden">
            <div className="text-[10px] uppercase font-mono tracking-wider opacity-80">Pursuer Radar</div>
            <div className="text-xs font-bold font-mono truncate tracking-tight mt-0.5">
              {threatText}
            </div>
          </div>
          <Flame className="w-5 h-5 shrink-0 ml-1" />
        </div>
      </div>
    </div>
  );
};
