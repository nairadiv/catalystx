import { Position } from './types';

// Numeric representation of tile types in level grids
export const TILE_EMPTY = 0;
export const TILE_WALL = 1;
export const TILE_GATE_ALPHA = 2; // Active in phase 0
export const TILE_GATE_BETA = 3;  // Active in phase 1
export const TILE_GATE_GAMMA = 4; // Active in phase 2 (3-phase maps)
export const TILE_SHARD = 5;
export const TILE_EXIT = 9;

/**
 * Checks whether a tile is currently solid (wall/closed gate) or walkable.
 */
export function isTileWalkable(
  tile: number, 
  phase: number, 
  cycleLength: number = 2,
  isOccupiedByEntity: boolean = false
): boolean {
  if (tile === TILE_WALL) return false;
  if (tile === TILE_EMPTY || tile === TILE_EXIT || tile === TILE_SHARD) return true;

  // If player or hunter is currently standing on a shifting tile, crush safety keeps it passable
  if (isOccupiedByEntity) return true;

  if (cycleLength === 2) {
    // 2-Phase toggle:
    // Phase 0: Gate Alpha is SOLID (closed), Gate Beta is OPEN
    // Phase 1: Gate Alpha is OPEN, Gate Beta is SOLID (closed)
    if (tile === TILE_GATE_ALPHA) return phase !== 0;
    if (tile === TILE_GATE_BETA) return phase !== 1;
  } else if (cycleLength === 3) {
    // 3-Phase rotation:
    // Phase 0: Gate Alpha is SOLID
    // Phase 1: Gate Beta is SOLID
    // Phase 2: Gate Gamma is SOLID
    if (tile === TILE_GATE_ALPHA) return phase !== 0;
    if (tile === TILE_GATE_BETA) return phase !== 1;
    if (tile === TILE_GATE_GAMMA) return phase !== 2;
  }

  return true;
}

/**
 * Breadth-First Search (BFS) for shortest path between two points on the current grid
 */
export function findShortestPath(
  start: Position,
  target: Position,
  grid: number[][],
  phase: number,
  cycleLength: number,
  playerPos?: Position,
  hunterPos?: Position
): Position[] | null {
  const height = grid.length;
  const width = grid[0].length;

  if (start.x === target.x && start.y === target.y) {
    return [start];
  }

  const queue: Position[] = [start];
  const visited = new Set<string>();
  const parentMap = new Map<string, Position>();

  const startKey = `${start.x},${start.y}`;
  visited.add(startKey);

  const directions = [
    { x: 0, y: -1 }, // North
    { x: 1, y: 0 },  // East
    { x: 0, y: 1 },  // South
    { x: -1, y: 0 }, // West
  ];

  while (queue.length > 0) {
    const current = queue.shift()!;
    const curKey = `${current.x},${current.y}`;

    if (current.x === target.x && current.y === target.y) {
      // Reconstruct path
      const path: Position[] = [];
      let step: Position | undefined = current;
      while (step) {
        path.unshift(step);
        const pKey = `${step.x},${step.y}`;
        step = parentMap.get(pKey);
      }
      return path;
    }

    for (const d of directions) {
      const nx = current.x + d.x;
      const ny = current.y + d.y;

      if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;

      const key = `${nx},${ny}`;
      if (visited.has(key)) continue;

      const tile = grid[ny][nx];
      const isOccupied = (playerPos?.x === nx && playerPos?.y === ny) || 
                         (hunterPos?.x === nx && hunterPos?.y === ny);

      // Check walkability
      if (!isTileWalkable(tile, phase, cycleLength, isOccupied)) {
        continue;
      }

      visited.add(key);
      parentMap.set(key, current);
      queue.push({ x: nx, y: ny });
    }
  }

  return null; // No path found
}

/**
 * Determines hunter's next position.
 * The hunter pathfinds toward the player using BFS through valid corridors.
 * If no path exists in this state (e.g. temporarily partitioned), hunter stays put.
 */
export function getNextHunterMove(
  hunterPos: Position,
  playerPos: Position,
  grid: number[][],
  phase: number,
  cycleLength: number
): Position {
  const path = findShortestPath(hunterPos, playerPos, grid, phase, cycleLength, playerPos, hunterPos);
  
  if (path && path.length > 1) {
    return path[1]; // Next adjacent step toward player
  }
  
  return hunterPos; // Hold position
}

/**
 * Checks if a path currently exists from player to exit.
 * Used to verify the guarantee that the maze remains solvable.
 */
export function isMazeSolvable(
  playerPos: Position,
  exitPos: Position,
  grid: number[][],
  phase: number,
  cycleLength: number
): boolean {
  const path = findShortestPath(playerPos, exitPos, grid, phase, cycleLength, playerPos);
  return path !== null;
}

export interface DynamicSolveResult {
  solvable: boolean;
  minMoves: number;
  visitedStates: number;
}

/**
 * Full Game-State BFS Solver:
 * Exhaustively searches state space (player_x, player_y, phase, hunter_x, hunter_y)
 * considering dynamic maze shifts and hunter pursuit to prove the level is 100% winnable.
 */
export function verifyLevelDynamicSolvability(
  playerStart: Position,
  hunterStart: Position,
  exitPos: Position,
  grid: number[][],
  cycleLength: number,
  maxStates: number = 50000
): DynamicSolveResult {
  interface State {
    px: number;
    py: number;
    phase: number;
    hx: number;
    hy: number;
    moves: number;
  }

  const queue: State[] = [{
    px: playerStart.x,
    py: playerStart.y,
    phase: 0,
    hx: hunterStart.x,
    hy: hunterStart.y,
    moves: 0
  }];

  const visited = new Set<string>();
  visited.add(`${playerStart.x},${playerStart.y},0,${hunterStart.x},${hunterStart.y}`);

  const directions = [
    { x: 0, y: -1 }, // North
    { x: 1, y: 0 },  // East
    { x: 0, y: 1 },  // South
    { x: -1, y: 0 }, // West
    { x: 0, y: 0 },  // Wait / Pass turn in place
  ];

  const height = grid.length;
  const width = grid[0].length;

  while (queue.length > 0) {
    const cur = queue.shift()!;

    if (visited.size > maxStates) {
      // Reached state budget
      return { solvable: false, minMoves: -1, visitedStates: visited.size };
    }

    for (const d of directions) {
      const nx = cur.px + d.x;
      const ny = cur.py + d.y;

      if (nx < 0 || nx >= width || ny < 0 || ny >= height) continue;

      // If moving to a different tile, check walkability
      if (d.x !== 0 || d.y !== 0) {
        const tile = grid[ny][nx];
        const isOccupiedByHunter = (cur.hx === nx && cur.hy === ny);
        if (!isTileWalkable(tile, cur.phase, cycleLength, isOccupiedByHunter)) {
          continue;
        }
      }

      // Check immediate exit reach
      if (nx === exitPos.x && ny === exitPos.y) {
        return { solvable: true, minMoves: cur.moves + 1, visitedStates: visited.size };
      }

      // Immediate collision with hunter
      if (nx === cur.hx && ny === cur.hy) {
        continue; // Caught
      }

      // Maze shifts
      const nextPhase = (cur.phase + 1) % cycleLength;

      // Hunter advances
      const nextHunter = getNextHunterMove(
        { x: cur.hx, y: cur.hy },
        { x: nx, y: ny },
        grid,
        nextPhase,
        cycleLength
      );

      // Check if hunter caught player
      if (nextHunter.x === nx && nextHunter.y === ny) {
        continue; // Caught
      }

      const key = `${nx},${ny},${nextPhase},${nextHunter.x},${nextHunter.y}`;
      if (!visited.has(key)) {
        visited.add(key);
        queue.push({
          px: nx,
          py: ny,
          phase: nextPhase,
          hx: nextHunter.x,
          hy: nextHunter.y,
          moves: cur.moves + 1
        });
      }
    }
  }

  return { solvable: false, minMoves: -1, visitedStates: visited.size };
}

