import { LevelData } from './types';
import { 
  TILE_EMPTY as _, 
  TILE_WALL as W, 
  TILE_GATE_ALPHA as A, 
  TILE_GATE_BETA as B, 
  TILE_GATE_GAMMA as C, 
  TILE_SHARD as S, 
  TILE_EXIT as E 
} from './pathfinding';

export const LEVELS: LevelData[] = [
  // ==========================================
  // LEVEL 1: Tutorial
  // Introduces movement, conduits, and maze shifting.
  // ==========================================
  {
    id: 1,
    name: "Sector 1: The Echo Threshold",
    subtitle: "Tutorial // Binary Shift",
    description: "Every step you take alternates the conduits. Gate A and Gate B swap states. The Hunter awakens behind you.",
    width: 11,
    height: 11,
    playerStart: { x: 1, y: 1 },
    hunterStart: { x: 1, y: 9 },
    exit: { x: 9, y: 9 },
    shiftCycleLength: 2,
    parMoves: 22,
    lore: "The ancient sanctuary reconfigures with every heartbeat. Stay ahead of the shadow.",
    layout: [
      // 0  1  2  3  4  5  6  7  8  9  10
      [ W, W, W, W, W, W, W, W, W, W, W ], // 0
      [ W, _, _, _, W, S, _, _, _, _, W ], // 1: Player (1,1), Shard (5,1)
      [ W, _, W, _, W, W, W, _, W, _, W ], // 2
      [ W, _, W, _, _, A, _, _, W, _, W ], // 3: Gate A (5,3)
      [ W, _, W, W, _, W, _, W, W, _, W ], // 4
      [ W, _, _, _, _, W, _, _, _, _, W ], // 5: Central intersection
      [ W, _, W, W, _, W, _, W, W, _, W ], // 6
      [ W, _, W, _, _, B, _, _, W, _, W ], // 7: Gate B (5,7)
      [ W, _, W, _, W, W, W, _, W, _, W ], // 8
      [ W, _, _, _, _, _, _, _, _, E, W ], // 9: Hunter (1,9), Exit (9,9)
      [ W, W, W, W, W, W, W, W, W, W, W ], // 10
    ]
  },

  // ==========================================
  // LEVEL 2: Simple maze with more turns
  // Weaving paths and corner gates.
  // ==========================================
  {
    id: 2,
    name: "Sector 2: The Sinuous Corridors",
    subtitle: "Angular Traversal",
    description: "Sharp turns and zig-zag corridors test your agility. Conduits alternate at key junction corners.",
    width: 11,
    height: 11,
    playerStart: { x: 1, y: 1 },
    hunterStart: { x: 9, y: 1 },
    exit: { x: 9, y: 9 },
    shiftCycleLength: 2,
    parMoves: 26,
    lore: "Sound reflects off angular basalt walls. Winding paths allow you to break the Hunter's line of sight.",
    layout: [
      // 0  1  2  3  4  5  6  7  8  9  10
      [ W, W, W, W, W, W, W, W, W, W, W ], // 0
      [ W, _, _, _, W, _, _, _, _, _, W ], // 1: Player (1,1), Hunter (9,1)
      [ W, _, W, _, W, _, W, W, W, _, W ], // 2
      [ W, _, W, _, _, A, _, _, W, _, W ], // 3: Gate A (5,3)
      [ W, _, W, W, W, W, W, _, W, _, W ], // 4
      [ W, _, _, S, _, _, _, _, _, _, W ], // 5: Shard (3,5)
      [ W, W, W, W, W, _, W, W, W, _, W ], // 6
      [ W, _, _, _, _, B, _, _, W, _, W ], // 7: Gate B (5,7)
      [ W, _, W, W, W, _, W, _, W, _, W ], // 8
      [ W, _, _, _, W, _, _, _, _, E, W ], // 9: Exit (9,9)
      [ W, W, W, W, W, W, W, W, W, W, W ], // 10
    ]
  },

  // ==========================================
  // LEVEL 3: More complex gate placement
  // Parallel channels and synchronized barriers.
  // ==========================================
  {
    id: 3,
    name: "Sector 3: The Interlocking Gates",
    subtitle: "Chamber Conduits",
    description: "Two distinct barrier zones shift in sync. Use closed gates to temporarily seal the Hunter out.",
    width: 13,
    height: 13,
    playerStart: { x: 1, y: 1 },
    hunterStart: { x: 11, y: 1 },
    exit: { x: 11, y: 11 },
    shiftCycleLength: 2,
    parMoves: 34,
    lore: "Sound travels faster than flesh. Time your passage so the walls lock your pursuer behind you.",
    layout: [
      // 0  1  2  3  4  5  6  7  8  9  10 11 12
      [ W, W, W, W, W, W, W, W, W, W, W, W, W ], // 0
      [ W, _, _, _, _, W, S, W, _, _, _, _, W ], // 1: Player (1,1), Shard (6,1), Hunter (11,1)
      [ W, _, W, W, _, W, _, W, _, W, W, _, W ], // 2
      [ W, _, W, _, _, A, _, B, _, _, W, _, W ], // 3: Gate A (5,3), Gate B (7,3)
      [ W, _, W, _, W, W, _, W, W, _, W, _, W ], // 4
      [ W, _, _, _, W, _, _, _, W, _, _, _, W ], // 5
      [ W, _, A, _, _, _, W, _, _, _, B, _, W ], // 6: Gate A (2,6), Gate B (10,6)
      [ W, _, _, _, W, _, _, _, W, _, _, _, W ], // 7
      [ W, _, W, _, W, W, _, W, W, _, W, _, W ], // 8
      [ W, _, W, _, _, B, _, A, _, _, W, _, W ], // 9: Gate B (5,9), Gate A (7,9)
      [ W, _, W, W, _, W, _, W, _, W, W, _, W ], // 10
      [ W, S, _, _, _, W, _, W, _, _, _, E, W ], // 11: Shard (1,11), Exit (11,11)
      [ W, W, W, W, W, W, W, W, W, W, W, W, W ], // 12
    ]
  },

  // ==========================================
  // LEVEL 4: Longer routes and narrow corridors
  // Constricted 1-tile avenues with timing alcoves.
  // ==========================================
  {
    id: 4,
    name: "Sector 4: The Narrow Descent",
    subtitle: "Constricted Corridors",
    description: "Long single-tile avenues with few crossing points. Time your transitions across the central conduit.",
    width: 13,
    height: 13,
    playerStart: { x: 1, y: 1 },
    hunterStart: { x: 1, y: 11 },
    exit: { x: 11, y: 11 },
    shiftCycleLength: 2,
    parMoves: 36,
    lore: "Narrow corridors amplify the echo of approaching steps. Keep moving forward.",
    layout: [
      // 0  1  2  3  4  5  6  7  8  9  10 11 12
      [ W, W, W, W, W, W, W, W, W, W, W, W, W ], // 0
      [ W, _, _, _, W, _, _, _, W, _, _, _, W ], // 1: Player (1,1)
      [ W, _, W, _, W, _, W, _, W, _, W, _, W ], // 2
      [ W, _, W, _, _, A, W, _, _, B, W, _, W ], // 3: Gate A (5,3), Gate B (9,3)
      [ W, _, W, W, W, _, W, W, W, _, W, _, W ], // 4
      [ W, _, _, _, W, _, _, S, W, _, _, _, W ], // 5: Shard (7,5)
      [ W, W, W, _, W, W, A, W, W, _, W, W, W ], // 6: Central Gate A (6,6)
      [ W, _, _, _, W, S, _, _, W, _, _, _, W ], // 7: Shard (5,7)
      [ W, _, W, W, W, _, W, W, W, _, W, _, W ], // 8
      [ W, _, W, _, _, B, W, _, _, A, W, _, W ], // 9: Gate B (5,9), Gate A (9,9)
      [ W, _, W, _, W, _, W, _, W, _, W, _, W ], // 10
      [ W, _, _, _, W, _, _, _, W, _, _, E, W ], // 11: Hunter (1,11), Exit (11,11)
      [ W, W, W, W, W, W, W, W, W, W, W, W, W ], // 12
    ]
  },

  // ==========================================
  // LEVEL 5: More complex Gate A & Gate B interactions
  // Symmetrical valve chambers with lock-in mechanics.
  // ==========================================
  {
    id: 5,
    name: "Sector 5: The Harmonic Valve",
    subtitle: "Dual Phase Synchronization",
    description: "Symmetric valve chambers alternate between two states. Trap the Hunter in one wing while you traverse the other.",
    width: 13,
    height: 13,
    playerStart: { x: 1, y: 6 },
    hunterStart: { x: 11, y: 6 },
    exit: { x: 6, y: 11 },
    shiftCycleLength: 2,
    parMoves: 32,
    lore: "Twin chambers breathe in resonance. Stepping forward in one room closes the portal in another.",
    layout: [
      // 0  1  2  3  4  5  6  7  8  9  10 11 12
      [ W, W, W, W, W, W, W, W, W, W, W, W, W ], // 0
      [ W, _, _, _, _, _, S, _, _, _, _, _, W ], // 1: Shard (6,1)
      [ W, _, W, W, W, _, W, _, W, W, W, _, W ], // 2
      [ W, _, W, _, A, _, W, _, B, _, W, _, W ], // 3: Gate A (4,3), Gate B (8,3)
      [ W, _, W, _, W, W, W, W, W, _, W, _, W ], // 4
      [ W, _, _, _, _, _, W, _, _, _, _, _, W ], // 5
      [ W, _, W, W, A, _, _, _, B, W, W, _, W ], // 6: Player (1,6), Gate A (4,6), Gate B (8,6), Hunter (11,6)
      [ W, _, _, _, _, _, W, _, _, _, _, _, W ], // 7
      [ W, _, W, _, W, W, W, W, W, _, W, _, W ], // 8
      [ W, _, W, _, B, _, W, _, A, _, W, _, W ], // 9: Gate B (4,9), Gate A (8,9)
      [ W, _, W, W, W, _, _, _, W, W, W, _, W ], // 10
      [ W, _, _, _, _, W, E, W, _, _, S, _, W ], // 11: Exit (6,11), Shard (10,11)
      [ W, W, W, W, W, W, W, W, W, W, W, W, W ], // 12
    ]
  },

  // ==========================================
  // LEVEL 6: Multiple possible routes and strategically placed dead ends
  // Branching catacombs with risky relic diversions.
  // ==========================================
  {
    id: 6,
    name: "Sector 6: The Forked Catacombs",
    subtitle: "Divergent Pathways",
    description: "Multiple paths lead toward the exit, but several branch into dead ends. Shifting gates alter the safe path.",
    width: 15,
    height: 15,
    playerStart: { x: 1, y: 1 },
    hunterStart: { x: 1, y: 13 },
    exit: { x: 13, y: 13 },
    shiftCycleLength: 2,
    parMoves: 44,
    lore: "The catacombs deceive the unobservant. A dead end in one phase may become an escape route in the next.",
    layout: [
      // 0  1  2  3  4  5  6  7  8  9  10 11 12 13 14
      [ W, W, W, W, W, W, W, W, W, W, W, W, W, W, W ], // 0
      [ W, _, _, _, W, _, _, _, _, _, W, _, _, _, W ], // 1: Player (1,1)
      [ W, _, W, _, W, _, W, W, W, _, W, _, W, _, W ], // 2
      [ W, _, W, _, _, A, _, _, W, _, _, B, W, _, W ], // 3: Gate A (5,3), Gate B (11,3)
      [ W, _, W, W, W, W, W, _, W, _, W, W, W, _, W ], // 4
      [ W, _, _, _, _, S, W, _, _, _, W, S, _, _, W ], // 5: Shards (5,5), (11,5)
      [ W, W, W, A, W, _, W, _, W, _, W, _, W, W, W ], // 6: Gate A (3,6)
      [ W, _, _, _, W, _, _, _, W, _, _, _, _, _, W ], // 7
      [ W, W, W, _, W, _, W, _, W, _, W, B, W, W, W ], // 8: Gate B (11,8)
      [ W, _, _, _, W, _, W, _, _, _, W, _, _, _, W ], // 9
      [ W, _, W, W, W, _, W, W, W, W, W, W, W, _, W ], // 10
      [ W, _, W, _, _, B, _, _, W, _, _, A, W, _, W ], // 11: Gate B (5,11), Gate A (11,11)
      [ W, _, W, _, W, W, W, _, W, _, W, _, W, _, W ], // 12
      [ W, _, _, _, _, S, _, _, _, _, W, _, _, E, W ], // 13: Hunter (1,13), Shard (5,13), Exit (13,13)
      [ W, W, W, W, W, W, W, W, W, W, W, W, W, W, W ], // 14
    ]
  },

  // ==========================================
  // LEVEL 7: Challenging navigation while avoiding the hunter
  // Center-hub pursuer with switchback isolation gates.
  // ==========================================
  {
    id: 7,
    name: "Sector 7: The Shadow Pursuit",
    subtitle: "Evasive Navigation",
    description: "The Hunter patrols from the central hub. Use the outer perimeter gates to isolate the pursuer.",
    width: 15,
    height: 15,
    playerStart: { x: 1, y: 1 },
    hunterStart: { x: 7, y: 7 },
    exit: { x: 13, y: 13 },
    shiftCycleLength: 2,
    parMoves: 46,
    lore: "The pursuer watches from the heart of the labyrinth. Step deliberately to close the inner sanctum.",
    layout: [
      // 0  1  2  3  4  5  6  7  8  9  10 11 12 13 14
      [ W, W, W, W, W, W, W, W, W, W, W, W, W, W, W ], // 0
      [ W, _, _, _, _, _, _, W, _, _, _, _, _, _, W ], // 1: Player (1,1)
      [ W, _, W, W, W, W, _, W, _, W, W, W, W, _, W ], // 2
      [ W, _, W, _, _, A, _, _, _, B, _, _, W, _, W ], // 3: Gate A (5,3), Gate B (9,3)
      [ W, _, W, _, W, W, W, _, W, W, W, _, W, _, W ], // 4
      [ W, _, _, _, W, S, _, _, _, S, W, _, _, _, W ], // 5: Shards (5,5), (9,5)
      [ W, W, W, _, W, _, W, A, W, _, W, _, W, W, W ], // 6: Gate A (7,6)
      [ W, _, _, _, _, _, B, _, A, _, _, _, _, _, W ], // 7: Gate B (6,7), Hunter (7,7), Gate A (8,7)
      [ W, W, W, _, W, _, W, B, W, _, W, _, W, W, W ], // 8: Gate B (7,8)
      [ W, _, _, _, W, _, _, _, _, S, W, _, _, _, W ], // 9: Shard (9,9)
      [ W, _, W, _, W, W, W, _, W, W, W, _, W, _, W ], // 10
      [ W, _, W, _, _, B, _, _, _, A, _, _, W, _, W ], // 11: Gate B (5,11), Gate A (9,11)
      [ W, _, W, W, W, W, _, W, _, W, W, W, W, _, W ], // 12
      [ W, _, _, _, _, _, _, W, _, _, _, _, _, E, W ], // 13: Exit (13,13)
      [ W, W, W, W, W, W, W, W, W, W, W, W, W, W, W ], // 14
    ]
  },

  // ==========================================
  // LEVEL 8: Complex shifting corridors (Tri-Phase)
  // 3-phase resonance with Gates Alpha, Beta, Gamma.
  // ==========================================
  {
    id: 8,
    name: "Sector 8: The Resonant Citadel",
    subtitle: "Tri-Phase Resonance",
    description: "A 3-phase shifting cycle (Alpha -> Beta -> Gamma). Only one barrier type solidifies at a time. Plan your route.",
    width: 15,
    height: 15,
    playerStart: { x: 1, y: 1 },
    hunterStart: { x: 13, y: 1 },
    exit: { x: 13, y: 13 },
    shiftCycleLength: 3,
    parMoves: 48,
    lore: "In the heart of the Labyrinth, ancient stone pillars rise and sink like breathing lungs. The exit is close.",
    layout: [
      // 0  1  2  3  4  5  6  7  8  9  10 11 12 13 14
      [ W, W, W, W, W, W, W, W, W, W, W, W, W, W, W ], // 0
      [ W, _, _, _, W, _, _, S, _, _, W, _, _, _, W ], // 1: Player (1,1), Shard (7,1), Hunter (13,1)
      [ W, _, W, _, W, _, W, W, W, _, W, _, W, _, W ], // 2
      [ W, _, W, _, _, A, _, W, _, B, _, _, W, _, W ], // 3: Gate A (5,3), Gate B (9,3)
      [ W, _, W, W, W, W, _, W, _, W, W, W, W, _, W ], // 4
      [ W, _, _, _, _, _, _, C, _, _, _, _, _, _, W ], // 5: Gate C (7,5)
      [ W, W, W, _, W, W, W, _, W, W, W, _, W, W, W ], // 6
      [ W, S, _, A, _, _, _, W, _, _, _, B, _, S, W ], // 7: Shards (1,7), (13,7); Gates A (3,7), B (11,7)
      [ W, W, W, _, W, W, W, _, W, W, W, _, W, W, W ], // 8
      [ W, _, _, _, _, _, _, C, _, _, _, _, _, _, W ], // 9: Gate C (7,9)
      [ W, _, W, W, W, W, _, W, _, W, W, W, W, _, W ], // 10
      [ W, _, W, _, _, B, _, W, _, A, _, _, W, _, W ], // 11: Gate B (5,11), Gate A (9,11)
      [ W, _, W, _, W, _, W, W, W, _, W, _, W, _, W ], // 12
      [ W, _, _, _, W, _, _, _, _, _, W, _, _, E, W ], // 13: Exit (13,13)
      [ W, W, W, W, W, W, W, W, W, W, W, W, W, W, W ], // 14
    ]
  },

  // ==========================================
  // LEVEL 9: High difficulty, requiring careful planning
  // Chrono-spatial concentric ring sanctuary.
  // ==========================================
  {
    id: 9,
    name: "Sector 9: The Obsidian Sanctum",
    subtitle: "Chrono-Spatial Sequence",
    description: "Concentric rings protected by rotating gates. Use waiting steps deliberately to align the conduits.",
    width: 15,
    height: 15,
    playerStart: { x: 1, y: 1 },
    hunterStart: { x: 13, y: 13 },
    exit: { x: 7, y: 7 },
    shiftCycleLength: 3,
    parMoves: 44,
    lore: "The inner sanctum reveals itself only to those who master the cadence of time and step.",
    layout: [
      // 0  1  2  3  4  5  6  7  8  9  10 11 12 13 14
      [ W, W, W, W, W, W, W, W, W, W, W, W, W, W, W ], // 0
      [ W, _, _, _, _, _, W, S, W, _, _, _, _, _, W ], // 1: Player (1,1), Shard (7,1)
      [ W, _, W, W, W, _, W, _, W, _, W, W, W, _, W ], // 2
      [ W, _, W, _, _, A, _, _, _, B, _, _, W, _, W ], // 3: Gate A (5,3), Gate B (9,3)
      [ W, _, W, _, W, W, W, _, W, W, W, _, W, _, W ], // 4
      [ W, _, _, A, W, _, _, _, _, _, W, B, _, _, W ], // 5: Gate A (3,5), Gate B (11,5)
      [ W, W, _, W, W, _, W, C, W, _, W, W, _, W, W ], // 6: Conduit C (7,6)
      [ W, S, _, _, _, _, A, E, B, _, _, _, _, S, W ], // 7: Shards (1,7),(13,7); Exit (7,7); Gates A (6,7), B (8,7)
      [ W, W, _, W, W, _, W, C, W, _, W, W, _, W, W ], // 8: Conduit C (7,8)
      [ W, _, _, B, W, _, _, _, _, _, W, A, _, _, W ], // 9: Gate B (3,9), Gate A (11,9)
      [ W, _, W, _, W, W, W, _, W, W, W, _, W, _, W ], // 10
      [ W, _, W, _, _, B, _, _, _, A, _, _, W, _, W ], // 11: Gate B (5,11), Gate A (9,11)
      [ W, _, W, W, W, _, W, _, W, _, W, W, W, _, W ], // 12
      [ W, _, _, _, _, _, W, _, W, _, _, _, _, _, W ], // 13: Hunter (13,13)
      [ W, W, W, W, W, W, W, W, W, W, W, W, W, W, W ], // 14
    ]
  },

  // ==========================================
  // LEVEL 10: Final Challenge
  // 4-quadrant grand master labyrinth.
  // ==========================================
  {
    id: 10,
    name: "Sector 10: The Core of the Echo",
    subtitle: "Master Protocol // The Final Escape",
    description: "The deepest sanctum. Four quadrant chambers with tri-phase conduits. Outthink the relentless shadow to achieve escape.",
    width: 15,
    height: 15,
    playerStart: { x: 1, y: 1 },
    hunterStart: { x: 13, y: 1 },
    exit: { x: 13, y: 13 },
    shiftCycleLength: 3,
    parMoves: 54,
    lore: "Every echo converges here. Beyond the final portal lies the outer world. Never hesitate.",
    layout: [
      // 0  1  2  3  4  5  6  7  8  9  10 11 12 13 14
      [ W, W, W, W, W, W, W, W, W, W, W, W, W, W, W ], // 0
      [ W, _, _, _, W, _, _, S, _, _, W, _, _, _, W ], // 1: Player (1,1), Shard (7,1), Hunter (13,1)
      [ W, _, W, _, W, _, W, _, W, _, W, _, W, _, W ], // 2
      [ W, _, W, _, _, A, W, _, W, B, _, _, W, _, W ], // 3: Gate A (5,3), Gate B (9,3)
      [ W, _, W, W, W, _, W, C, W, _, W, W, W, _, W ], // 4: Gate C (7,4)
      [ W, _, _, _, W, _, _, _, _, _, W, _, _, _, W ], // 5
      [ W, W, W, C, W, W, _, W, _, W, W, C, W, W, W ], // 6: Gates C (3,6), C (11,6)
      [ W, S, _, _, _, _, A, _, B, _, _, _, _, S, W ], // 7: Shards (1,7),(13,7); Gates A (6,7), B (8,7)
      [ W, W, W, C, W, W, _, W, _, W, W, C, W, W, W ], // 8: Gates C (3,8), C (11,8)
      [ W, _, _, _, W, _, _, _, _, _, W, _, _, _, W ], // 9
      [ W, _, W, W, W, _, W, C, W, _, W, W, W, _, W ], // 10: Gate C (7,10)
      [ W, _, W, _, _, B, W, _, W, A, _, _, W, _, W ], // 11: Gate B (5,11), Gate A (9,11)
      [ W, _, W, _, W, _, W, _, W, _, W, _, W, _, W ], // 12
      [ W, _, _, _, W, _, _, S, _, _, W, _, _, E, W ], // 13: Shard (7,13), Exit (13,13)
      [ W, W, W, W, W, W, W, W, W, W, W, W, W, W, W ], // 14
    ]
  }
];
