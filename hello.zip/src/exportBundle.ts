import { LEVELS } from './levels';

/**
 * Generates a self-contained, single-file HTML/CSS/JS export
 * of ECHO//ESCAPE for competition judges and standalone deployment.
 * Supports all 10 progressively difficult, handcrafted levels.
 */
export function generateStandaloneHtml(): string {
  const levelsJson = JSON.stringify(
    LEVELS.map(l => ({
      id: l.id,
      name: l.name,
      w: l.width,
      h: l.height,
      pStart: l.playerStart,
      hStart: l.hunterStart,
      exit: l.exit,
      cycle: l.shiftCycleLength,
      grid: l.layout
    }))
  );

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ECHO//ESCAPE - Standalone Competition Edition (10 Levels)</title>
  <style>
    :root {
      --bg: #070a12;
      --navy: #0e1526;
      --blue: #1e293b;
      --purple: #3b0764;
      --purple-light: #7e22ce;
      --gold: #f59e0b;
      --gold-light: #fbbf24;
      --cyan: #06b6d4;
      --red: #ef4444;
      --text: #f1f5f9;
      --text-muted: #94a3b8;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: var(--bg);
      color: var(--text);
      font-family: 'Courier New', Courier, monospace, system-ui;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 12px;
      user-select: none;
    }
    header {
      text-align: center;
      margin-bottom: 8px;
    }
    h1 {
      font-size: 22px;
      letter-spacing: 3px;
      color: var(--gold);
      text-shadow: 0 0 12px rgba(245, 158, 11, 0.4);
    }
    .hud {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 12px;
      font-size: 12px;
      background: var(--navy);
      border: 1px solid #1e293b;
      padding: 8px 14px;
      border-radius: 6px;
      margin-bottom: 10px;
      align-items: center;
      max-width: 500px;
      width: 100%;
    }
    .hud span { color: var(--gold-light); font-weight: bold; }
    #canvas-container {
      position: relative;
      border: 2px solid #312e81;
      border-radius: 8px;
      overflow: hidden;
      box-shadow: 0 0 30px rgba(79, 70, 229, 0.2);
      background: #090d18;
      max-width: min(480px, calc(100vh - 300px));
      max-height: min(480px, calc(100vh - 300px));
      width: 100%;
      aspect-ratio: 1 / 1;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    canvas {
      width: 100%;
      height: 100%;
      display: block;
      image-rendering: pixelated;
    }
    .controls {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 6px;
      margin-top: 10px;
    }
    .btn-row { display: flex; gap: 8px; }
    button {
      background: #1e1b4b;
      color: #e0e7ff;
      border: 1px solid #4338ca;
      padding: 7px 12px;
      border-radius: 4px;
      font-family: inherit;
      font-size: 12px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.15s ease;
    }
    button:hover {
      background: #312e81;
      border-color: var(--gold);
      color: #fff;
    }
    .dpad-btn { width: 40px; height: 40px; font-size: 15px; padding: 0; }
    .overlay {
      position: absolute;
      inset: 0;
      background: rgba(7, 10, 18, 0.94);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 24px;
      text-align: center;
      z-index: 10;
    }
    .overlay h2 { font-size: 20px; margin-bottom: 10px; }
    .overlay.win h2 { color: var(--gold); }
    .overlay.lose h2 { color: var(--red); }
    .overlay p { font-size: 13px; color: var(--text-muted); margin-bottom: 16px; max-width: 320px; line-height: 1.5; }
    .legend {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 10px;
      font-size: 11px;
      color: var(--text-muted);
      margin-top: 10px;
    }
    .legend-item { display: flex; align-items: center; gap: 4px; }
    .legend-box { width: 10px; height: 10px; border-radius: 2px; }
    .level-select {
      display: flex;
      gap: 4px;
      flex-wrap: wrap;
      justify-content: center;
      margin-bottom: 8px;
    }
    .lvl-btn {
      padding: 3px 7px;
      font-size: 11px;
      background: #111827;
      border: 1px solid #1f293d;
    }
    .lvl-btn.active {
      background: #312e81;
      color: var(--gold);
      border-color: var(--gold);
    }
  </style>
</head>
<body>

<header>
  <h1>ECHO // ESCAPE</h1>
  <div style="font-size: 11px; color: #94a3b8; margin-top: 2px;">10 PROGRESSIVE LABYRINTH PROTOCOLS</div>
</header>

<div class="level-select" id="level-buttons"></div>

<div class="hud">
  <div>LEVEL: <span id="hud-level">1</span>/10</div>
  <div>MOVES: <span id="hud-moves">0</span></div>
  <div>SHIFT: <span id="hud-phase" style="color: #38bdf8;">1/2</span></div>
  <div>HUNTER: <span id="hud-dist" style="color: #f87171;">--</span></div>
  <div>SHARDS: <span id="hud-shards">0/1</span></div>
</div>

<div id="canvas-container">
  <canvas id="game-canvas" width="480" height="480"></canvas>
  <div id="game-overlay" class="overlay" style="display: none;">
    <h2 id="overlay-title">SECTOR ESCAPED!</h2>
    <p id="overlay-msg">You navigated through the shifting conduits.</p>
    <button id="overlay-btn" onclick="handleOverlayAction()">CONTINUE</button>
  </div>
</div>

<div class="controls">
  <div class="btn-row">
    <button class="dpad-btn" onclick="move(0, -1)">W</button>
  </div>
  <div class="btn-row">
    <button class="dpad-btn" onclick="move(-1, 0)">A</button>
    <button class="dpad-btn" onclick="move(0, 1)">S</button>
    <button class="dpad-btn" onclick="move(1, 0)">D</button>
  </div>
  <div class="btn-row" style="margin-top: 4px;">
    <button onclick="passTurn()">WAIT / SHIFT (Space)</button>
    <button onclick="restartLevel()">RESTART (R)</button>
    <button onclick="toggleSound()" id="sound-btn">SOUND: ON</button>
  </div>
</div>

<div class="legend">
  <div class="legend-item"><div class="legend-box" style="background:#fbbf24;"></div> Player</div>
  <div class="legend-item"><div class="legend-box" style="background:#ef4444;"></div> Hunter</div>
  <div class="legend-item"><div class="legend-box" style="background:#06b6d4;"></div> Gate A</div>
  <div class="legend-item"><div class="legend-box" style="background:#a855f7;"></div> Gate B</div>
  <div class="legend-item"><div class="legend-box" style="background:#d97706;"></div> Gate C</div>
  <div class="legend-item"><div class="legend-box" style="background:#eab308; border-radius: 50%;"></div> Exit</div>
</div>

<script>
// --- AUDIO SYNTHESIZER ---
const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
let soundEnabled = true;

function playSound(type) {
  if (!soundEnabled || !audioCtx) return;
  if (audioCtx.state === 'suspended') audioCtx.resume();
  const now = audioCtx.currentTime;

  if (type === 'step') {
    const osc = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(160, now + 0.04);
    g.gain.setValueAtTime(0.06, now);
    g.gain.linearRampToValueAtTime(0.001, now + 0.04);
    osc.connect(g); g.connect(audioCtx.destination);
    osc.start(now); osc.stop(now + 0.05);
  } else if (type === 'shift') {
    const osc = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.1);
    g.gain.setValueAtTime(0.08, now);
    g.gain.linearRampToValueAtTime(0.001, now + 0.1);
    osc.connect(g); g.connect(audioCtx.destination);
    osc.start(now); osc.stop(now + 0.11);
  } else if (type === 'hunter') {
    const osc = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(75, now);
    osc.frequency.linearRampToValueAtTime(50, now + 0.12);
    g.gain.setValueAtTime(0.09, now);
    g.gain.linearRampToValueAtTime(0.001, now + 0.12);
    osc.connect(g); g.connect(audioCtx.destination);
    osc.start(now); osc.stop(now + 0.13);
  } else if (type === 'win') {
    [440, 554, 659, 880].forEach((f, i) => {
      const osc = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + i * 0.09);
      g.gain.setValueAtTime(0.1, now + i * 0.09);
      g.gain.linearRampToValueAtTime(0.001, now + i * 0.09 + 0.15);
      osc.connect(g); g.connect(audioCtx.destination);
      osc.start(now + i * 0.09); osc.stop(now + i * 0.09 + 0.16);
    });
  } else if (type === 'lose') {
    const osc = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(40, now + 0.3);
    g.gain.setValueAtTime(0.14, now);
    g.gain.linearRampToValueAtTime(0.001, now + 0.3);
    osc.connect(g); g.connect(audioCtx.destination);
    osc.start(now); osc.stop(now + 0.32);
  }
}

function toggleSound() {
  soundEnabled = !soundEnabled;
  document.getElementById('sound-btn').innerText = 'SOUND: ' + (soundEnabled ? 'ON' : 'OFF');
}

// --- 10 HANDCRAFTED LEVELS ---
const LEVELS = ${levelsJson};

// --- GAME STATE ---
let currentLevelIdx = 0;
let level = LEVELS[0];
let grid = [];
let player = { x: 1, y: 1 };
let hunter = { x: 1, y: 9 };
let shiftPhase = 0;
let moves = 0;
let shardsCollected = 0;
let totalShards = 0;
let campaignMoves = 0;
let campaignShards = 0;
let gameState = 'PLAYING'; // PLAYING, WON, LOST, ALL_CLEAR

const canvas = document.getElementById('game-canvas');
const ctx = canvas.getContext('2d');

function renderLevelButtons() {
  const container = document.getElementById('level-buttons');
  container.innerHTML = '';
  LEVELS.forEach((l, idx) => {
    const btn = document.createElement('button');
    btn.className = 'lvl-btn' + (idx === currentLevelIdx ? ' active' : '');
    btn.innerText = (idx + 1);
    btn.onclick = () => initLevel(idx);
    container.appendChild(btn);
  });
}

function initLevel(idx) {
  currentLevelIdx = idx;
  level = LEVELS[idx];
  grid = level.grid.map(row => [...row]);
  player = { ...level.pStart };
  hunter = { ...level.hStart };
  shiftPhase = 0;
  moves = 0;
  shardsCollected = 0;
  
  totalShards = 0;
  for (let r = 0; r < level.h; r++) {
    for (let c = 0; c < level.w; c++) {
      if (grid[r][c] === 5) totalShards++;
    }
  }

  gameState = 'PLAYING';
  document.getElementById('game-overlay').style.display = 'none';
  renderLevelButtons();
  updateHud();
  render();
}

function isWalkable(tile, phase, cycle, isEntity) {
  if (tile === 1) return false;
  if (isEntity) return true; // crush protection
  if (cycle === 2) {
    if (tile === 2) return phase !== 0;
    if (tile === 3) return phase !== 1;
  } else if (cycle === 3) {
    if (tile === 2) return phase !== 0;
    if (tile === 3) return phase !== 1;
    if (tile === 4) return phase !== 2;
  }
  return true;
}

function findShortestPath(start, goal) {
  if (start.x === goal.x && start.y === goal.y) return [start];
  const queue = [start];
  const visited = new Set();
  const parent = new Map();
  visited.add(start.x + ',' + start.y);

  const dirs = [{x:0, y:-1}, {x:1, y:0}, {x:0, y:1}, {x:-1, y:0}];

  while (queue.length > 0) {
    const cur = queue.shift();
    if (cur.x === goal.x && cur.y === goal.y) {
      const path = [];
      let s = cur;
      while (s) {
        path.unshift(s);
        s = parent.get(s.x + ',' + s.y);
      }
      return path;
    }

    for (const d of dirs) {
      const nx = cur.x + d.x;
      const ny = cur.y + d.y;
      if (nx < 0 || nx >= level.w || ny < 0 || ny >= level.h) continue;
      const key = nx + ',' + ny;
      if (visited.has(key)) continue;

      const tile = grid[ny][nx];
      const isEntity = (player.x === nx && player.y === ny) || (hunter.x === nx && hunter.y === ny);
      if (!isWalkable(tile, shiftPhase, level.cycle, isEntity)) continue;

      visited.add(key);
      parent.set(key, cur);
      queue.push({ x: nx, y: ny });
    }
  }
  return null;
}

function move(dx, dy) {
  if (gameState !== 'PLAYING') return;
  const nx = player.x + dx;
  const ny = player.y + dy;

  if (nx < 0 || nx >= level.w || ny < 0 || ny >= level.h) return;

  const tile = grid[ny][nx];
  if (!isWalkable(tile, shiftPhase, level.cycle, false)) {
    return; // Bumped into wall
  }

  // Valid move
  player.x = nx;
  player.y = ny;
  moves++;
  playSound('step');

  // Check shard pickup
  if (grid[ny][nx] === 5) {
    grid[ny][nx] = 0;
    shardsCollected++;
  }

  // Check exit reached before shift/hunter step
  if (player.x === level.exit.x && player.y === level.exit.y) {
    handleWin();
    return;
  }

  // Maze shifts!
  shiftPhase = (shiftPhase + 1) % level.cycle;
  playSound('shift');

  // Hunter advances
  advanceHunter();

  // Collision check
  if (hunter.x === player.x && hunter.y === player.y) {
    handleGameOver();
    return;
  }

  updateHud();
  render();
}

function passTurn() {
  if (gameState !== 'PLAYING') return;
  moves++;
  shiftPhase = (shiftPhase + 1) % level.cycle;
  playSound('shift');
  advanceHunter();

  if (hunter.x === player.x && hunter.y === player.y) {
    handleGameOver();
    return;
  }
  updateHud();
  render();
}

function advanceHunter() {
  const path = findShortestPath(hunter, player);
  if (path && path.length > 1) {
    hunter = { x: path[1].x, y: path[1].y };
    playSound('hunter');
  }
}

function handleWin() {
  gameState = 'WON';
  playSound('win');
  render();
  const overlay = document.getElementById('game-overlay');
  overlay.className = 'overlay win';
  overlay.style.display = 'flex';
  
  if (currentLevelIdx < LEVELS.length - 1) {
    document.getElementById('overlay-title').innerText = 'SECTOR ' + (currentLevelIdx + 1) + ' ESCAPED!';
    document.getElementById('overlay-msg').innerText = 'Cleared in ' + moves + ' moves with ' + shardsCollected + '/' + totalShards + ' relics.';
    document.getElementById('overlay-btn').innerText = 'CONTINUE TO SECTOR ' + (currentLevelIdx + 2);
  } else {
    gameState = 'ALL_CLEAR';
    document.getElementById('overlay-title').innerText = 'ALL 10 SECTORS ESCAPED!';
    document.getElementById('overlay-msg').innerText = 'Master of the Echo! You conquered all 10 shifting labyrinth protocols!';
    document.getElementById('overlay-btn').innerText = 'PLAY AGAIN (SECTOR 1)';
  }
}

function handleGameOver() {
  gameState = 'LOST';
  playSound('lose');
  render();
  const overlay = document.getElementById('game-overlay');
  overlay.className = 'overlay lose';
  overlay.style.display = 'flex';
  document.getElementById('overlay-title').innerText = 'CAUGHT BY THE SHADOW';
  document.getElementById('overlay-msg').innerText = 'The Hunter cornered you. The echoes fade into darkness.';
  document.getElementById('overlay-btn').innerText = 'RESTART LEVEL (R)';
}

function handleOverlayAction() {
  if (gameState === 'WON') {
    campaignMoves += moves;
    campaignShards += shardsCollected;
    initLevel(currentLevelIdx + 1);
  } else if (gameState === 'ALL_CLEAR') {
    campaignMoves = 0;
    campaignShards = 0;
    initLevel(0);
  } else {
    initLevel(currentLevelIdx);
  }
}

function restartLevel() {
  initLevel(currentLevelIdx);
}

function updateHud() {
  document.getElementById('hud-level').innerText = (currentLevelIdx + 1);
  document.getElementById('hud-moves').innerText = moves;
  document.getElementById('hud-phase').innerText = (shiftPhase + 1) + '/' + level.cycle;
  document.getElementById('hud-shards').innerText = shardsCollected + '/' + totalShards;

  const path = findShortestPath(hunter, player);
  const distEl = document.getElementById('hud-dist');
  if (path) {
    const dist = path.length - 1;
    distEl.innerText = dist + ' TILES';
    distEl.style.color = dist <= 3 ? '#ef4444' : (dist <= 6 ? '#f59e0b' : '#10b981');
  } else {
    distEl.innerText = 'BLOCKED BY GATE';
    distEl.style.color = '#38bdf8';
  }
}

function render() {
  const tileSize = Math.floor(canvas.width / level.w);
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Background
  ctx.fillStyle = '#090d18';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Render Grid
  for (let r = 0; r < level.h; r++) {
    for (let c = 0; c < level.w; c++) {
      const tile = grid[r][c];
      const x = c * tileSize;
      const y = r * tileSize;

      if (tile === 1) { // Wall
        ctx.fillStyle = '#1e1b4b';
        ctx.fillRect(x, y, tileSize, tileSize);
        ctx.strokeStyle = '#312e81';
        ctx.strokeRect(x + 1, y + 1, tileSize - 2, tileSize - 2);
      } else if (tile === 2) { // Gate A
        const isSolid = shiftPhase === 0;
        ctx.fillStyle = isSolid ? '#0891b2' : 'rgba(8, 145, 178, 0.15)';
        ctx.fillRect(x, y, tileSize, tileSize);
        ctx.fillStyle = isSolid ? '#cffafe' : '#0891b2';
        ctx.font = '10px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('A', x + tileSize/2, y + tileSize/2);
      } else if (tile === 3) { // Gate B
        const isSolid = shiftPhase === 1;
        ctx.fillStyle = isSolid ? '#7e22ce' : 'rgba(126, 34, 206, 0.15)';
        ctx.fillRect(x, y, tileSize, tileSize);
        ctx.fillStyle = isSolid ? '#f3e8ff' : '#7e22ce';
        ctx.font = '10px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('B', x + tileSize/2, y + tileSize/2);
      } else if (tile === 4) { // Gate Gamma
        const isSolid = shiftPhase === 2;
        ctx.fillStyle = isSolid ? '#d97706' : 'rgba(217, 119, 6, 0.15)';
        ctx.fillRect(x, y, tileSize, tileSize);
        ctx.fillStyle = isSolid ? '#fef3c7' : '#d97706';
        ctx.font = '10px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('C', x + tileSize/2, y + tileSize/2);
      } else if (tile === 5) { // Shard
        ctx.fillStyle = '#fbbf24';
        ctx.beginPath();
        ctx.arc(x + tileSize/2, y + tileSize/2, tileSize * 0.22, 0, Math.PI * 2);
        ctx.fill();
      }

      // Exit
      if (r === level.exit.y && c === level.exit.x) {
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(x + 4, y + 4, tileSize - 8, tileSize - 8);
        ctx.strokeStyle = '#fff';
        ctx.strokeRect(x + 6, y + 6, tileSize - 12, tileSize - 12);
      }

      // Subtle grid line
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
      ctx.strokeRect(x, y, tileSize, tileSize);
    }
  }

  // Draw Player
  const px = player.x * tileSize;
  const py = player.y * tileSize;
  ctx.fillStyle = '#fbbf24';
  ctx.fillRect(px + 4, py + 4, tileSize - 8, tileSize - 8);
  ctx.fillStyle = '#000';
  ctx.fillRect(px + 7, py + 8, 3, 3);
  ctx.fillRect(px + tileSize - 10, py + 8, 3, 3);

  // Draw Hunter
  const hx = hunter.x * tileSize;
  const hy = hunter.y * tileSize;
  ctx.fillStyle = '#ef4444';
  ctx.fillRect(hx + 4, hy + 4, tileSize - 8, tileSize - 8);
  ctx.fillStyle = '#fff';
  ctx.fillRect(hx + 7, hy + 8, 3, 3);
  ctx.fillRect(hx + tileSize - 10, hy + 8, 3, 3);
}

// Keyboard input
window.addEventListener('keydown', (e) => {
  const k = e.key.toLowerCase();
  if (k === 'arrowup' || k === 'w') { e.preventDefault(); move(0, -1); }
  else if (k === 'arrowdown' || k === 's') { e.preventDefault(); move(0, 1); }
  else if (k === 'arrowleft' || k === 'a') { e.preventDefault(); move(-1, 0); }
  else if (k === 'arrowright' || k === 'd') { e.preventDefault(); move(1, 0); }
  else if (k === ' ' || k === 'spacebar') { e.preventDefault(); passTurn(); }
  else if (k === 'r') { e.preventDefault(); restartLevel(); }
});

// Start game
initLevel(0);
</script>
</body>
</html>`;
}
